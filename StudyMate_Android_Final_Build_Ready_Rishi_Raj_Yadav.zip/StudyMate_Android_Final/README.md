# StudyMate — Android Build-Ready Project

**App:** StudyMate  
**Package ID:** `com.rishirajyadav.studymate`  
**Developer:** Rishi Raj Yadav  
**Version:** 1.0.0

## What is included

- `www/` — the working StudyMate web app used by the Android wrapper
- Semester 1–6 syllabus/unit structure
- Notes, Quick Revision, MCQ, VVI and Quiz UI from the current working version
- Figures and study resources included in the web app
- `capacitor.config.ts` — Android wrapper configuration
- `package.json` — Capacitor dependencies
- `.github/workflows/build-apk.yml` — automatic APK/AAB build

## Build on GitHub Actions

1. Create a new GitHub repository.
2. Upload **all contents of this folder** to the repository root.
3. Commit to `main` (or `master`).
4. Open **Actions → Build StudyMate APK and AAB**.
5. Run the workflow with **Run workflow** if it did not start automatically.
6. When it finishes, open the workflow run and download:
   - `StudyMate-debug-apk` → installable APK for testing.
   - `StudyMate-release-aab-unsigned` → AAB for signing before Play Store upload.

## Important

The generated release AAB is **unsigned**. Google Play requires a properly signed release bundle. For a Play Store release, configure Android/Gradle signing with your own keystore and keep the keystore credentials out of the repository.

## Local build

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug bundleRelease
```

The source content is based on the StudyMate files already prepared in this project. No new syllabus claims have been added here.
