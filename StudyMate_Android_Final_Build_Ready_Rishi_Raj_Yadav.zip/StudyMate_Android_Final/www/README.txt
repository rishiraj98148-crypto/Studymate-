StudyMate — SPCK single-file build with syllabus-structured detailed notes.
All note content is embedded in index.html so SPCK preview does not depend on fetch().
Source basis: supplied CTEVT syllabus PDFs; explanatory text is study-aid content organized around those syllabus topics.
