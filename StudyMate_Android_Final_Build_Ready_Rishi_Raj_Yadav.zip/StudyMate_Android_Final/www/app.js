// StudyMate navigation — uses the semester data files loaded by index.html
// StudyMate navigation
const D = {semester1: window.semester1, semester2: window.semester2, semester3: window.semester3, semester4: window.semester4, semester5: window.semester5, semester6: window.semester6};
let sem = null, sub = null, unit = null, mode = 'notes';
const $ = id => document.getElementById(id);
function only(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active')); $(id).classList.add('active'); window.scrollTo(0,0);}
function goHome(){only('home'); renderSemesters();}
function showSubjects(){only('subjects'); renderSubjects();}
function showUnits(){only('units'); renderUnits();}
function openSem(id){sem=id; showSubjects();}
function openSub(id){sub=id; showUnits();}
function openUnit(id){unit=id; only('learn'); renderLearn();}
function renderSemesters(q=''){
  const query=(q||'').trim().toLowerCase();
  const list=Object.values(D).filter(x=>!query || (x.label+' '+x.title).toLowerCase().includes(query) || x.subjects.some(s=>(s.name+' '+(s.code||'')).toLowerCase().includes(query)));
  $('semesterGrid').innerHTML=list.map(x=>`<div class="card" onclick="openSem('${x.id}')"><span>${x.label}</span><b>${x.title}</b><span>${x.subjects.length} subjects</span></div>`).join('') || '<div class="panel">No matching semester or subject found.</div>';
}
function renderSubjects(){
  const x=D[sem]; if(!x)return;
  $('subjectHead').innerHTML=`<h2 class="headTitle">${x.label}</h2><p class="muted">${x.title}</p>`;
  $('subjectList').innerHTML=x.subjects.map(s=>`<div class="item" onclick="openSub('${s.id}')"><div><b>${s.name}</b><small>${s.code||''}</small></div><span>›</span></div>`).join('');
}
function renderUnits(){
  const x=D[sem], s=x&&x.subjects.find(z=>z.id===sub); if(!s)return;
  $('unitHead').innerHTML=`<h2 class="headTitle">${s.name}</h2><p class="muted">Syllabus units / chapters</p>`;
  $('unitList').innerHTML=s.units.map(u=>`<div class="item" onclick="openUnit('${u.id}')"><div><b>${u.name}</b><small>${(u.topics||[]).length} topics</small></div><span>›</span></div>`).join('');
}
const noteMap={
  'Map Scale':'Map scale expresses the relationship between a distance on a map and the corresponding distance on the ground. In this syllabus it is studied together with map design, enlargement and reduction.',
  'Map Projection':'A map projection is the method of representing the curved Earth on a plane map. The syllabus covers classification, distortion, scale factor, UTM and MUTM/grid systems used in Nepal.',
  'Graphic Variables':'Graphic variables are visual properties used to communicate geographic information on a map. The syllabus emphasizes their importance, visual perception and types.',
  'Generalization':'Generalization is the process of simplifying or adapting map information when preparing a map at a particular scale. The syllabus includes exaggeration, displacement and methods of generalization.',
  'Relief Representation':'Relief representation shows the form and elevation differences of terrain on maps. The syllabus lists spot height, hachuring, contouring, hill shading, layer tinting and 3D models.',
  'Digital Cartography':'Digital cartography covers computer-based map making. The syllabus includes raster/vector models, digital map-making steps, conventional versus digital cartography, DLM and DCM.',
  'Cadastral Surveying':'Cadastral surveying deals with surveying and mapping land parcels and their boundaries. The syllabus connects it with cadastral maps, documents, registration procedures and modern cadastre.',
  'Total Station':'Total Station is listed in the syllabus as an instrument used for digital cadastral and numerical survey work, including data acquisition and coordinate plotting.',
  'GNSS':'GNSS is covered as a satellite-based positioning technology. The syllabus includes its components, positioning techniques, field procedures and use in surveying.',
  'GPS Data Transformation':'GPS data transformation includes concepts of geoid, ellipsoid, local/global datum and datum transformation parameters.',
  'Coordinate Systems':'The syllabus covers geographical and rectangular coordinates and the concept of conversion between them.',
  'Satellite Orbits':'The syllabus covers different satellite types, orbit types, Kepler’s law and orbital elements.',
  'Spherical triangle':'A spherical triangle is part of the astronomy syllabus and is studied with the astronomical triangle, spherical trigonometric laws and spherical excess.',
  'Hatching':'Hatching is included under CAD drawing commands for representing areas with a hatch pattern.',
  'Layers':'Layers are a CAD feature used to organize drawing objects and manage their properties.',
  'Contour generation':'Contour generation is included in the CAD/LD application unit and is related to creating terrain representation from survey data.',
  'Plane Table':'Plane Table surveying is a graphical surveying method covered with accessories, setup, orientation, radiation, intersection, traversing and resection.',
  'Tacheometry':'Tacheometric surveying is covered through stadia, tangential and subtense-bar systems, distance/elevation formulae, constants, errors and field procedure.',
  'EDM':'EDM is listed as a digital instrument topic in numerical topographical surveying.',
  'Topographical survey':'Topographical surveying covers planimetric and altimetric details, natural/artificial features, contours and graphical/numerical field methods.'
};
function explainTopic(t){
  if(noteMap[t]) return noteMap[t];
  const key=Object.keys(noteMap).find(k=>t.toLowerCase().includes(k.toLowerCase())||k.toLowerCase().includes(t.toLowerCase()));
  if(key) return noteMap[key];
  return `Syllabus topic: ${t}. Revise its definition, principle/procedure, field or mapping application, and important examination points.`;
}
function makeMCQ(topics){
  return topics.slice(0,8).map((t,i)=>({q:`Which topic is explicitly included in this unit?`,opts:[t,'Unlisted topic','Not part of this unit','None of these'],a:0}));
}
const noteFiles={
  s1apn:'notes/semester 1/Applied_Nepali.md',
  s1ape:'notes/semester 1/Applied_English.md',
  s1math:'notes/semester 1/Engineering_Mathematics_I.md',
  s1phy:'notes/semester 1/Engineering_Physics_I.md',
  s1chem:'notes/semester 1/Engineering_Chemistry_I.md',
  s1draw:'notes/semester 1/Engineering_Drawing_I.md',
  s1comp:'notes/semester 1/Computer_Application.md',
  s2math:'notes/semester 2/Engineering_Mathematics_II.md',
  s2phy:'notes/semester 2/Engineering_Physics_II.md',
  s2chem:'notes/semester 2/Engineering_Chemistry_II.md',
  s2work:'notes/semester 2/Workshop_Practice_I.md',
  s2draw:'notes/semester 2/Engineering_Drawing_II.md',
  s2mech:'notes/semester 2/Applied_Mechanics.md',
  s3fs:'notes/semester 3/Fundamental_of_Surveying_and_Geomatics.md',
  s3control:'notes/semester 3/Control_Survey.md',
  s3inst:'notes/semester 3/Survey_Instruments_Concepts.md',
  s3math:'notes/semester 3/Survey_Mathematics_and_Computation.md',
  s3gis:'notes/semester 3/GIS_Basics.md',
  s5geo:'notes/semester 5/Geodesy_and_Astronomy.md',
  s5civil:'notes/semester 5/Basic_Construction_and_Quantity_Survey.md',
  s5cad:'notes/semester 5/Cadastral_Surveying.md',
  s5land:'notes/semester 5/Land_Administration_and_Land_Laws.md',
  s5mgmt:'notes/semester 5/Survey_Management.md',
  s6eng:'notes/semester 6/Engineering_Survey.md',
  s6ent:'notes/semester 6/Entrepreneurship_Development.md',
  s6civil:'notes/semester 6/Civil_Construction_and_Quantity_Estimation.md',
  s6social:'notes/semester 6/Fundamental_of_Social_Science_and_Environment.md',
  s6project:'notes/semester 6/Project_Work.md',
  s4cart:'notes/semester 4/01_Cartography.md',
  s4cad:'notes/semester 4/02_Cadastral_Surveying.md',
  s4geo:'notes/semester 4/03_Geodesy_and_Astronomy.md',
  s4ldcad:'notes/semester 4/04_Land_Development_and_CAD.md',
  s4topo:'notes/semester 4/05_Topographical_Survey.md'
};
const noteCache={};
function escapeHtml(v){return String(v).replace(/[&<>'"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));}
function markdownToHtml(md){
  const lines=md.replace(/\r/g,'').split('\n');
  let out='', inList=false;
  const closeList=()=>{if(inList){out+='</ul>';inList=false;}};
  for(const raw of lines){
    const line=raw.trimEnd();
    if(!line.trim()){closeList();continue;}
    if(/^###\s+/.test(line)){closeList();out+=`<h4>${escapeHtml(line.replace(/^###\s+/,''))}</h4>`;continue;}
    if(/^##\s+/.test(line)){closeList();out+=`<h3>${escapeHtml(line.replace(/^##\s+/,''))}</h3>`;continue;}
    if(/^#\s+/.test(line)){closeList();out+=`<h2>${escapeHtml(line.replace(/^#\s+/,''))}</h2>`;continue;}
    if(/^[-*]\s+/.test(line)){if(!inList){out+='<ul>';inList=true;}out+=`<li>${escapeHtml(line.replace(/^[-*]\s+/,''))}</li>`;continue;}
    if(/^\d+\.\s+/.test(line)){closeList();out+=`<p><b>${escapeHtml(line.match(/^\d+\./)[0])}</b> ${escapeHtml(line.replace(/^\d+\.\s+/,''))}</p>`;continue;}
    closeList();
    let text=escapeHtml(line);
    text=text.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`(.+?)`/g,'<code>$1</code>');
    out+=`<p>${text}</p>`;
  }
  closeList();
  return out;
}
function extractUnitMarkdown(md, unitNumber){
  const lines=md.replace(/\r/g,'').split('\n');
  const re=/^#{2,3}\s+Unit\s+([0-9]+)\s*:/i;
  let start=-1,end=lines.length;
  for(let i=0;i<lines.length;i++){
    const m=lines[i].match(re);
    if(m && Number(m[1])===Number(unitNumber)){start=i;break;}
  }
  if(start<0)return null;
  for(let i=start+1;i<lines.length;i++){
    const m=lines[i].match(re);
    if(m && Number(m[1])!==Number(unitNumber)){end=i;break;}
  }
  return lines.slice(start,end).join('\n').trim();
}
async function loadRealNote(subjectId, unitNumber){
  const key=subjectId+'::'+unitNumber;
  if(noteCache[key])return noteCache[key];
  // Primary source: embedded notes. This works in SPCK even when fetch() of local .md files is blocked.
  try{
    const embedded=window.studyNotes && window.studyNotes[subjectId];
    if(embedded){
      const section=extractUnitMarkdown(embedded,unitNumber);
      if(section){noteCache[key]=section;return section;}
    }
  }catch(e){console.warn('Embedded StudyMate note error:',e);}
  // Secondary source: markdown file, useful when the app is served over HTTP.
  const file=noteFiles[subjectId];
  if(!file)return null;
  try{
    const res=await fetch(file,{cache:'no-store'});
    if(!res.ok)throw new Error('HTTP '+res.status);
    const md=await res.text();
    const section=extractUnitMarkdown(md,unitNumber);
    if(section){noteCache[key]=section;return section;}
  }catch(e){console.warn('StudyMate note load failed:',file,e);}
  return null;
}
function renderFallbackNotes(u){
  const topics=u.topics||[];
  return `<div class="panel"><h3>📘 Syllabus-based Notes</h3><p class="muted">Detailed note file could not be loaded, so the syllabus topics are shown below.</p>${topics.map((t,i)=>`<article class="note"><h4>${i+1}. ${escapeHtml(t)}</h4><p>${escapeHtml(explainTopic(t))}</p></article>`).join('')}</div>`;
}
async function renderLearn(){
  const x=D[sem], s=x&&x.subjects.find(z=>z.id===sub), u=s&&s.units.find(z=>z.id===unit); if(!u)return;
  $('learnHead').innerHTML=`<h2 class="headTitle">${escapeHtml(u.name)}</h2><p class="muted">${escapeHtml(s.name)} • ${escapeHtml(x.label)}</p>`;
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));
  const topics=u.topics||[], c=$('content');
  if(mode==='notes'){
    const unitNumber=Number(String(u.id).replace(/\D/g,'')) || (s.units.indexOf(u)+1);
    c.innerHTML='<div class="panel"><p class="muted">⏳ Loading Notes…</p></div>';
    const md=await loadRealNote(s.id,unitNumber);
    if(md){
      c.innerHTML=`<div class="panel real-notes"><h3>📘 Complete Notes</h3><p class="muted">Notes loaded from the StudyMate Notes file for this unit.</p>${markdownToHtml(md)}</div>`;
    }else c.innerHTML=renderFallbackNotes(u);
    return;
  }
  if(mode==='mcq') c.innerHTML=`<div class="panel"><h3>📝 MCQ Practice</h3>${makeMCQ(topics).map((q,i)=>`<div class="question"><b>Q${i+1}. ${q.q}</b>${q.opts.map((o,j)=>`<button class="option" onclick="checkOption(this,${j===q.a})">${String.fromCharCode(65+j)}. ${escapeHtml(o)}</button>`).join('')}</div>`).join('')}</div>`;
  if(mode==='vvi') c.innerHTML=`<div class="panel"><h3>⭐ VVI / Exam Practice</h3><p class="muted">Questions are drafted from the syllabus topic headings; they are not quoted from an official question paper.</p><ol>${topics.map(t=>`<li class="question">Define / explain <b>${escapeHtml(t)}</b> and write the relevant principle, method, application or example.</li>`).join('')}</ol></div>`;
  if(mode==='quiz') c.innerHTML=`<div class="panel"><h3>🎯 Quick Quiz</h3><p class="muted">Select the topic that belongs to this unit.</p>${makeMCQ(topics).slice(0,5).map((q,i)=>`<div class="question"><b>Q${i+1}. ${q.q}</b>${q.opts.map((o,j)=>`<button class="option" onclick="checkOption(this,${j===q.a})">${String.fromCharCode(65+j)}. ${escapeHtml(o)}</button>`).join('')}</div>`).join('')}</div>`;
}
function checkOption(btn,correct){
  const q=btn.parentElement;
  q.querySelectorAll('.option').forEach(b=>b.disabled=true);
  btn.textContent=(correct?'✓ ':'✗ ')+btn.textContent;
}

document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{mode=b.dataset.mode;renderLearn();}));
  $('themeBtn').addEventListener('click',()=>{document.body.classList.toggle('dark');localStorage.smDark=document.body.classList.contains('dark')?'1':'0';});
  if(localStorage.smDark==='1')document.body.classList.add('dark');
  $('search').addEventListener('input',e=>renderSemesters(e.target.value));
  renderSemesters();
});
