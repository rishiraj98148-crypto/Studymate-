# Applied English

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Technology

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 1 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Money and Economy

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 2 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Human Culture

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 3 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Ecology and Environment

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 4 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Career Opportunities

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 5 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Human Rights

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 6 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: War and Peace

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 7 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Music and Creation

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 8 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Migration and Diaspora

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 9 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 10: Power and Politics

### Key points
- **Reading comprehension and terminology:** Reading comprehension requires identifying the main idea, supporting details, meaning of words from context and the writer’s purpose. Answers should be based on the information contained in the passage.
- **Writing/communication skill:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Grammar and language use:** Grammar provides rules for forming correct sentences. Focus on parts of speech, tense, agreement, articles, prepositions and sentence structure according to the specific exercise.
- **Practice questions:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 10 focuses on: Reading comprehension and terminology, Writing/communication skill, Grammar and language use, Practice questions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 11: Short Stories

### Key points
- **The Treasure in the Forest:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.
- **My Old Home:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.
- **The Half-closed Eyes of the Buddha and the Slowly Sinking Sun:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.
- **A Very Old Man with Enormous Wings:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 11 focuses on: The Treasure in the Forest, My Old Home, The Half-closed Eyes of the Buddha and the Slowly Sinking Sun, A Very Old Man with Enormous Wings.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 12: Poems

### Key points
- **The Awakening Age:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.
- **Soft Storm:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 12 focuses on: The Awakening Age, Soft Storm.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 13: Essays

### Key points
- **Knowledge and Wisdom:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.
- **Humility:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.
- **Human Rights and the Age of Inequality:** This Applied English topic develops reading, writing, vocabulary or communication ability. Learn the prescribed terminology, understand the main idea and practise constructing clear, grammatically appropriate responses.

### Quick revision
- Unit 13 focuses on: Knowledge and Wisdom, Humility, Human Rights and the Age of Inequality.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications