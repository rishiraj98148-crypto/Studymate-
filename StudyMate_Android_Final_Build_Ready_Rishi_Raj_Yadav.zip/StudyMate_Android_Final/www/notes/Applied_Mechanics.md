# Applied Mechanics

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction: Forces Acting on Particle and Rigid Body

### Key points
- **Mechanics and scope of applied mechanics:** Mechanics and scope of applied mechanics is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Particle, rigid and deformable body:** Particle, rigid and deformable body is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Force characteristics and classification:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Resolution/composition of forces:** Resolution/composition of forces is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Transmissibility, moment and Varignon’s theorem:** Transmissibility, moment and Varignon’s theorem is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Couple and its properties:** Couple and its properties is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 1 focuses on: Mechanics and scope of applied mechanics, Particle, rigid and deformable body, Force characteristics and classification, Resolution/composition of forces.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Equilibrium of Forces

### Key points
- **Equilibrium conditions:** Equilibrium conditions is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Free-body diagrams:** Free-body diagrams is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Two/three-dimensional equilibrium equations:** Two/three-dimensional equilibrium equations is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Triangle, parallelogram and polygon laws:** Triangle, parallelogram and polygon laws is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Lami’s theorem:** Lami’s theorem is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Resultant and equilibrant:** Resultant and equilibrant is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 2 focuses on: Equilibrium conditions, Free-body diagrams, Two/three-dimensional equilibrium equations, Triangle, parallelogram and polygon laws.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Friction

### Key points
- **Causes, types and effects of friction:** Causes, types and effects of friction is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Static/dynamic friction and coefficient:** Static/dynamic friction and coefficient is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Impending motion and motion:** Impending motion and motion is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Sliding/tipping:** Sliding/tipping is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Angle of friction and angle of repose:** Angle of friction and angle of repose is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Level and inclined-plane equilibrium:** Level and inclined-plane equilibrium is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 3 focuses on: Causes, types and effects of friction, Static/dynamic friction and coefficient, Impending motion and motion, Sliding/tipping.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Centre of Gravity and Centroid

### Key points
- **Centre of gravity, centre of mass and centroid:** Centre of gravity, centre of mass and centroid is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Composite lines and areas:** Composite lines and areas is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Centroid by integration:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.
- **Built-up plane figures:** Built-up plane figures is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **CG of simple solids:** CG of simple solids is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 4 focuses on: Centre of gravity, centre of mass and centroid, Composite lines and areas, Centroid by integration, Built-up plane figures.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Moment of Inertia

### Key points
- **First and second moment of area:** First and second moment of area is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Axial and polar MoI:** Axial and polar MoI is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Regular areas and centroidal axes:** Regular areas and centroidal axes is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Parallel/perpendicular axis theorems:** Parallel/perpendicular axis theorems is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Composite areas and radius of gyration:** Composite areas and radius of gyration is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Section modulus and principal MoI:** Section modulus and principal MoI is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 5 focuses on: First and second moment of area, Axial and polar MoI, Regular areas and centroidal axes, Parallel/perpendicular axis theorems.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Analysis of Statically Determinate Beams

### Key points
- **Structures, mechanisms and determinacy:** Structures, mechanisms and determinacy is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Types of load and support:** Types of load and support is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Types of beams:** Types of beams is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Support reactions and stability:** Support reactions and stability is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 6 focuses on: Structures, mechanisms and determinacy, Types of load and support, Types of beams, Support reactions and stability.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Axial Force, Shear Force and Bending Moments

### Key points
- **Axial, shear and bending moment definitions:** Axial, shear and bending moment definitions is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Sign convention and diagrams:** Sign convention and diagrams is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Load-SF-BM relationships:** Load-SF-BM relationships is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **UDL, point load and UVL on common beams:** UDL, point load and UVL on common beams is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 7 focuses on: Axial, shear and bending moment definitions, Sign convention and diagrams, Load-SF-BM relationships, UDL, point load and UVL on common beams.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Analysis of Statically Determinate Plane Truss

### Key points
- **Truss concept and assumptions:** Truss concept and assumptions is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Perfect/imperfect/deficient/redundant trusses:** Perfect/imperfect/deficient/redundant trusses is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Types of truss:** Types of truss is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Method of joints:** Method of joints is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Method of sections:** Method of sections is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 8 focuses on: Truss concept and assumptions, Perfect/imperfect/deficient/redundant trusses, Types of truss, Method of joints.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications