# Basic Construction and Quantity Survey

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction

### Key points
- **Construction and quantity surveying concept:** Quantity estimation determines the amount of work and materials required for a construction activity. Measurements are taken from drawings or field data, quantities are calculated using suitable geometric relations, and rates are then applied to prepare a cost estimate.
- **Role of surveyor in construction projects:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.

### Quick revision
- Unit 1 focuses on: Construction and quantity surveying concept, Role of surveyor in construction projects.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Construction Materials

### Key points
- **Cement, aggregates and concrete:** Construction materials and work items are selected according to their required properties and construction method. Proper proportioning, measurement, placement and curing are important for achieving the required strength and durability.
- **Bricks/blocks, steel and timber:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Properties and uses:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 2 focuses on: Cement, aggregates and concrete, Bricks/blocks, steel and timber, Properties and uses.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Building Construction

### Key points
- **Foundation, walls and floors:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Roofing and finishes:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Basic construction sequence:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 3 focuses on: Foundation, walls and floors, Roofing and finishes, Basic construction sequence.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Road Construction

### Key points
- **Road components and alignment:** Road construction involves preparation of the formation, drainage, subgrade and pavement layers according to the project requirements. Alignment, earthwork, materials, compaction and drainage are important considerations.
- **Earthwork and pavement basics:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Drainage and construction considerations:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 4 focuses on: Road components and alignment, Earthwork and pavement basics, Drainage and construction considerations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Irrigation System

### Key points
- **Irrigation purpose and components:** An irrigation system supplies water to agricultural land when natural rainfall is insufficient. The system includes a source, conveyance and distribution arrangements designed according to terrain and water demand.
- **Canals and basic structures:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Survey requirements:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 5 focuses on: Irrigation purpose and components, Canals and basic structures, Survey requirements.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: River Training Works

### Key points
- **River behaviour and training purpose:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Basic protection/training structures:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 6 focuses on: River behaviour and training purpose, Basic protection/training structures.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Water Supply System

### Key points
- **Sources and intake:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Conveyance, storage and distribution:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Basic network components:** A computer network connects devices so they can exchange data and share resources. The Internet is a global interconnection of networks that uses standard communication protocols to provide services such as web access and email.

### Quick revision
- Unit 7 focuses on: Sources and intake, Conveyance, storage and distribution, Basic network components.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications