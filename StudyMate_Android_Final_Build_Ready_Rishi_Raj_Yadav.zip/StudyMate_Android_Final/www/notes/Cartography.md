# Cartography – Semester 4 Notes
Course: EG 2201 GE

## Unit 1: Introduction
### 1.1 Cartography
Cartography is the field concerned with the preparation, design, presentation and reproduction of maps. It combines measurement, geographic information, graphical design and communication.

### 1.2 History of Cartography
Map making developed from simple sketches used to represent places into systematic surveying, printed maps and modern digital mapping. Modern cartography uses computers and digital spatial data.

### 1.3 Scope and Uses
Cartography is used in surveying, land administration, engineering planning, navigation, disaster management, resource management, environmental studies and GIS.

## Unit 2: Map
### Definition
A map is a reduced and generalized representation of geographic features on a plane surface using symbols and a specified scale.

### Types / Classification
Maps may be classified according to scale, purpose, content and method of preparation. Examples include topographic, cadastral and thematic maps.

### Map Scale
Scale expresses the relationship between a distance on the map and the corresponding ground distance. For representative fraction, RF = map distance / ground distance, using the same units.

### Drawing and Scribing
Drawing is the preparation of map information using lines, symbols and lettering. Scribing is a technique of producing precise lines or features on a prepared surface/film during conventional map production.

### Semiology
Map semiology deals with the meaning and use of graphic signs and symbols so that map information can be understood correctly.

### Map Design and Layout
Map design arranges title, map body, legend, scale, north direction, marginal information and other elements so the map communicates information clearly.

### Typonomy and Typography
Typonomy concerns naming/place-name treatment on maps. Typography concerns the design, selection, placement and appearance of lettering.

### Enlargement and Reduction
Enlargement increases map size while reduction decreases it. The scale must be changed consistently with the graphical dimensions.

### Uses of Maps
Maps support planning, navigation, surveying, land management, engineering design and communication of spatial information.

## Unit 3: Branches of Cartography
### Map Compilation
Map compilation is the process of collecting, selecting, organizing and drawing information to prepare a map.

### Main Steps
1. Define purpose and scale.
2. Collect source information.
3. Select and evaluate relevant features.
4. Establish the base.
5. Plot and symbolize features.
6. Generalize where required.
7. Edit, label and check.
8. Prepare the final map/reproduction.

Base maps provide fundamental reference information. Derived maps are prepared from existing maps/data. Special-purpose or thematic maps emphasize a selected theme.

## Unit 4: Graphic Variables
Graphic variables are visual properties used to distinguish and communicate map information. Examples include size, shape, orientation, texture/pattern and colour/value.

Visual perception is the way a map reader recognizes differences and relationships from graphic symbols. Good symbol selection should make important differences easy to perceive.

## Unit 5: Map Projection
A map projection is a systematic method of representing the curved Earth on a plane map.

### Classification
Projections can be classified by the developable surface or geometric construction and by the property they preserve, such as area, shape, distance or direction.

### Distortion and Scale Factor
Because a curved surface is represented on a plane, distortion may occur in shape, area, distance or direction. Scale factor expresses the relationship between map scale and corresponding scale on the reference surface.

### Choice of Projection
Choice depends on map purpose, area, location, extent and the property that should be preserved.

### UTM
Universal Transverse Mercator (UTM) is a transverse Mercator coordinate system using zones. It provides projected rectangular coordinates for mapping.

### MUTM and Nepal Grid
The syllabus specifically includes Modified UTM (MUTM) and the grid system used in Nepal. Study should focus on the purpose of the modification, grid coordinates and sheet/grid organization used for Nepalese mapping.

## Unit 6: Map Sheet Numbering
Sheet numbering provides a systematic identification of map sheets so that individual sheets can be referenced and indexed.

### International Small Scale System
It provides a standardized framework for identifying small-scale map sheets.

### Nepal Topographical Sheets
Nepal's topographical base maps are organized using a sheet-numbering system. Students should learn the prescribed sheet index, sheet identification and subdivision pattern used in Nepal.

### Nepal Cadastral Sheets
Cadastral map sheets are identified systematically for land-parcel mapping and record management.

## Unit 7: Generalization
Generalization is the controlled reduction and simplification of map information when a map is prepared at a smaller scale or when excessive detail would reduce readability.

### Aspects
Selection, simplification, displacement, exaggeration and classification are important aspects.

### Exaggeration
A feature too small to be represented clearly may be enlarged beyond its true scale to maintain visibility.

### Displacement
A feature may be shifted slightly to avoid overlap and preserve readability. The displacement should be controlled.

## Unit 8: Relief Representation
Relief means the variation of elevation and shape of the ground surface.

Methods in the syllabus:
- Spot height: numerical elevation at a point.
- Hachuring: short strokes indicating slope direction and relative steepness.
- Contouring: lines joining points of equal elevation.
- Hill shading: tonal effect used to show relief by simulated illumination.
- Layer tinting: colours/tints representing elevation ranges.
- 3D models: three-dimensional representation of terrain.
- Rock drawing: conventional representation of rock features.

## Unit 9: Colour
Light can be described in terms of visible wavelengths. Additive colour mixing uses light, while subtractive colour mixing concerns pigments/inks. A colour triangle/charts can help select and organize colours for map communication.

## Unit 10: Digital Cartography
Digital cartography uses computers and digital spatial data for map preparation.

### Raster and Vector
Raster represents information as cells/pixels. Vector represents features as points, lines and polygons.

### Digital Map Making – General Workflow
Data collection → data preparation → editing → symbolization → labeling → layout → quality checking → output/printing.

### Conventional vs Digital
Conventional mapping relies more on manual drawing and physical reproduction. Digital mapping allows editing, storage, duplication, analysis and automated output.

### DLM and DCM
Digital Landscape/Line/Map models and Digital Cartographic Models organize digital geographic and cartographic information for production and use; the exact implementation depends on the mapping system.

## Unit 11: Map Reproduction
Map reproduction converts a prepared map into reproducible/printable output.

Important terms in the syllabus include positive, negative, dia-positive, tone, screen and film; contact photography; camera photography; diazo reproduction; open window mask; plate making; colour proof and registration; and flat-bed, rotary offset and digital printing.

### Quality Control
Colour proof checks colour appearance. Registration checks the alignment of multiple colour plates/layers.

### Exam Focus
Definitions + differences (raster/vector, conventional/digital), map scale, projection and distortion, generalization, relief representation, sheet numbering, UTM/MUTM, and map reproduction processes are important revision areas.