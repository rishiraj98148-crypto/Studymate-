# Civil Construction and Quantity Estimation

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction

### Key points
- **Construction project basics:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Quantity estimation purpose and workflow:** Quantity estimation determines the amount of work and materials required for a construction activity. Measurements are taken from drawings or field data, quantities are calculated using suitable geometric relations, and rates are then applied to prepare a cost estimate.

### Quick revision
- Unit 1 focuses on: Construction project basics, Quantity estimation purpose and workflow.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Construction Materials

### Key points
- **Cement, aggregate, concrete:** Construction materials and work items are selected according to their required properties and construction method. Proper proportioning, measurement, placement and curing are important for achieving the required strength and durability.
- **Brick/block, steel and timber:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Material properties and uses:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 2 focuses on: Cement, aggregate, concrete, Brick/block, steel and timber, Material properties and uses.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Building Construction

### Key points
- **Foundation and superstructure:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Masonry, floors, roofs and finishes:** Construction materials and work items are selected according to their required properties and construction method. Proper proportioning, measurement, placement and curing are important for achieving the required strength and durability.

### Quick revision
- Unit 3 focuses on: Foundation and superstructure, Masonry, floors, roofs and finishes.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Road Construction

### Key points
- **Road earthwork and layers:** Layers organize drawing objects according to their purpose, such as boundaries, text, contours or utilities. Using separate layers makes editing, visibility control, symbolization and plotting easier.
- **Drainage and pavement basics:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 4 focuses on: Road earthwork and layers, Drainage and pavement basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Irrigation System

### Key points
- **Canals, structures and irrigation components:** An irrigation system supplies water to agricultural land when natural rainfall is insufficient. The system includes a source, conveyance and distribution arrangements designed according to terrain and water demand.

### Quick revision
- Unit 5 focuses on: Canals, structures and irrigation components.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: River Training Works

### Key points
- **River control and protection works:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 6 focuses on: River control and protection works.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Water Supply System

### Key points
- **Source, intake, conveyance and distribution:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 7 focuses on: Source, intake, conveyance and distribution.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Estimation

### Key points
- **Units and measurement rules:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.
- **Detailed quantity take-off:** Quantity estimation determines the amount of work and materials required for a construction activity. Measurements are taken from drawings or field data, quantities are calculated using suitable geometric relations, and rates are then applied to prepare a cost estimate.
- **Rate analysis and abstract estimate:** Construction and quantity surveying combine technical knowledge with measurement and costing. Study the construction sequence, materials, measurement units, quantity calculation and relevant specifications.

### Quick revision
- Unit 8 focuses on: Units and measurement rules, Detailed quantity take-off, Rate analysis and abstract estimate.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications