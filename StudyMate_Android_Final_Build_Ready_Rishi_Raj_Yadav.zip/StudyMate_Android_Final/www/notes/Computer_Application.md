# Computer Application

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction to Computers

### Key points
- **History and generations of computers:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Types of computers:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Hardware and software concepts:** Computer hardware consists of physical components such as the CPU, memory, storage, input devices and output devices. Each component performs a specific role in processing, storing or communicating information.

### Quick revision
- Unit 1 focuses on: History and generations of computers, Types of computers, Hardware and software concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Hardware Components

### Key points
- **Major blocks of a digital computer:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Input and output devices:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **CPU and memory: RAM, ROM, PROM, EPROM:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Auxiliary storage: magnetic, optical and flash storage:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.

### Quick revision
- Unit 2 focuses on: Major blocks of a digital computer, Input and output devices, CPU and memory: RAM, ROM, PROM, EPROM, Auxiliary storage: magnetic, optical and flash storage.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Operating System Software

### Key points
- **Importance and functions of OS:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **MS-DOS, Windows, Unix and Linux:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **File, device and memory management:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Internal/external commands and file/folder management:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.

### Quick revision
- Unit 3 focuses on: Importance and functions of OS, MS-DOS, Windows, Unix and Linux, File, device and memory management, Internal/external commands and file/folder management.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Application Packages

### Key points
- **Text editors:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Microsoft Word: editing, formatting, tables and graphics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Microsoft Excel: data, formulas, calculations and charts:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Database management and Microsoft Access:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Microsoft PowerPoint:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.

### Quick revision
- Unit 4 focuses on: Text editors, Microsoft Word: editing, formatting, tables and graphics, Microsoft Excel: data, formulas, calculations and charts, Database management and Microsoft Access.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Utility Programs

### Key points
- **Computer virus and antivirus:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Multimedia: audio, video and graphics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].

### Quick revision
- Unit 5 focuses on: Computer virus and antivirus, Multimedia: audio, video and graphics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Networks and Internet

### Key points
- **LAN, MAN and WAN:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Bus, ring and star topologies:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Hub, switch, modem and NIC:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **Network cabling and network OS:** A computer network connects devices so they can exchange data and share resources. The Internet is a global interconnection of networks that uses standard communication protocols to provide services such as web access and email.
- **Client-server, file/print sharing:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.
- **WWW, ISP, browsers, search engines and email:** Computers accept input, process data according to instructions, store information and produce output. Understanding the main components and their functions helps users select and operate computer systems correctly.

### Quick revision
- Unit 6 focuses on: LAN, MAN and WAN, Bus, ring and star topologies, Hub, switch, modem and NIC, Network cabling and network OS.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications