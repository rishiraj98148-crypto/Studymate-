# Engineering Chemistry I

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Language of Chemistry

### Key points
- **Chemical symbols and formulae:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.
- **Atomic and molecular mass:** The mole is the amount of substance containing Avogadro’s number of entities, approximately 6.022×10²³. Moles connect microscopic particles with measurable mass through n = m/M, where M is molar mass.
- **Mole concept and chemical equations:** The mole is the amount of substance containing Avogadro’s number of entities, approximately 6.022×10²³. Moles connect microscopic particles with measurable mass through n = m/M, where M is molar mass.
- **Basic chemical calculations:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.

### Quick revision
- Unit 1 focuses on: Chemical symbols and formulae, Atomic and molecular mass, Mole concept and chemical equations, Basic chemical calculations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: General Chemistry

### Key points
- **Atomic structure and periodic concepts:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Chemical bonding:** Chemical bonding is the attraction that holds atoms or ions together. Ionic bonding involves electron transfer and electrostatic attraction, while covalent bonding involves sharing of electron pairs; metallic bonding involves delocalized electrons.
- **Acids, bases and salts:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Solutions, concentration and pH:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Chemical reactions and stoichiometry:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.

### Quick revision
- Unit 2 focuses on: Atomic structure and periodic concepts, Chemical bonding, Acids, bases and salts, Solutions, concentration and pH.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: System of Classification

### Key points
- **Periodic table and periodic trends:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Classification of elements:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Properties and common compounds:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.
- **Engineering relevance of chemical materials:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.

### Quick revision
- Unit 3 focuses on: Periodic table and periodic trends, Classification of elements, Properties and common compounds, Engineering relevance of chemical materials.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications