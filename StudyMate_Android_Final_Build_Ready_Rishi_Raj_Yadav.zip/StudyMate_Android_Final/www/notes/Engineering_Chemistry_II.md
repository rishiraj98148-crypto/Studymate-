# Engineering Chemistry II

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Non-metals and their compounds

### Key points
- **Hydrogen, oxygen, nitrogen and halogens:** Hydrogen is the lightest element and commonly occurs in molecular form H₂. The syllabus considers its preparation, properties and important compounds or reactions relevant to engineering chemistry.
- **Important non-metal compounds:** Metals generally show metallic bonding, electrical and thermal conductivity, malleability and characteristic chemical reactivity. Engineering chemistry studies their extraction, properties, compounds, corrosion and uses.
- **Properties, preparation and uses:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.

### Quick revision
- Unit 1 focuses on: Hydrogen, oxygen, nitrogen and halogens, Important non-metal compounds, Properties, preparation and uses.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Metals and their compounds

### Key points
- **Metallurgy basics:** Metals generally show metallic bonding, electrical and thermal conductivity, malleability and characteristic chemical reactivity. Engineering chemistry studies their extraction, properties, compounds, corrosion and uses.
- **Properties of common metals:** Metals generally show metallic bonding, electrical and thermal conductivity, malleability and characteristic chemical reactivity. Engineering chemistry studies their extraction, properties, compounds, corrosion and uses.
- **Corrosion and prevention:** Corrosion is the deterioration of a metal through chemical or electrochemical interaction with its environment. Control methods include material selection, coatings, inhibitors and suitable environmental control.
- **Important metal compounds:** Metals generally show metallic bonding, electrical and thermal conductivity, malleability and characteristic chemical reactivity. Engineering chemistry studies their extraction, properties, compounds, corrosion and uses.

### Quick revision
- Unit 2 focuses on: Metallurgy basics, Properties of common metals, Corrosion and prevention, Important metal compounds.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Organic compounds and polymers

### Key points
- **Hydrocarbons and functional groups:** This chemistry topic should be studied through definitions, chemical formulae, properties, important reactions and engineering applications. Where the syllabus specifies preparation or detection, learn the procedure and observations in sequence.
- **Alcohols, aldehydes, ketones and acids:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Polymerization:** Organic chemistry studies carbon compounds. Hydrocarbons are classified by bonding, while polymers are large molecules formed from repeating monomer units and are important engineering materials.
- **Common engineering polymers and uses:** Organic chemistry studies carbon compounds. Hydrocarbons are classified by bonding, while polymers are large molecules formed from repeating monomer units and are important engineering materials.

### Quick revision
- Unit 3 focuses on: Hydrocarbons and functional groups, Alcohols, aldehydes, ketones and acids, Polymerization, Common engineering polymers and uses.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications