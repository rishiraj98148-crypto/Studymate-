# Engineering Drawing I

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction of Engineering Drawing

### Key points
- **Purpose and importance of engineering drawing:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Drawing instruments and materials:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Standard drawing conventions:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.

### Quick revision
- Unit 1 focuses on: Purpose and importance of engineering drawing, Drawing instruments and materials, Standard drawing conventions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Lettering, scales and dimensions

### Key points
- **Engineering lettering:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Plain, diagonal and comparative scales:** Engineering drawings communicate size and proportion through standard scales and dimensions. Dimensioning should be clear, complete and placed so that the intended measurement can be read without ambiguity.
- **Dimensioning principles and conventions:** Engineering drawings communicate size and proportion through standard scales and dimensions. Dimensioning should be clear, complete and placed so that the intended measurement can be read without ambiguity.

### Quick revision
- Unit 2 focuses on: Engineering lettering, Plain, diagonal and comparative scales, Dimensioning principles and conventions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Geometrical constructions

### Key points
- **Bisecting lines and angles:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Regular polygons:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Tangent and related constructions:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 3 focuses on: Bisecting lines and angles, Regular polygons, Tangent and related constructions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Engineering Curve

### Key points
- **Ellipse, parabola and hyperbola constructions:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Cycloid and other standard engineering curves:** Engineering curves are constructed using defined geometric or mathematical relationships. Accurate construction requires correct points, tangencies, divisions and smooth joining of the curve.

### Quick revision
- Unit 4 focuses on: Ellipse, parabola and hyperbola constructions, Cycloid and other standard engineering curves.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Conic Sections

### Key points
- **Focus-directrix concept:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Parabola, ellipse and hyperbola:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Construction methods:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.

### Quick revision
- Unit 5 focuses on: Focus-directrix concept, Parabola, ellipse and hyperbola, Construction methods.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Orthographic Projection

### Key points
- **Principles of orthographic projection:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **First/third angle concepts:** Engineering drawing is a graphical language used to communicate shape, size, position and construction information. Standard lines, lettering, scales, symbols and projection methods make drawings consistent and interpretable.
- **Projection of points, lines and planes:** A map projection transforms positions on the curved Earth to a plane. Because a curved surface cannot be flattened without distortion, projections are selected according to the purpose and region of mapping, considering distortion of distance, area, shape or direction.
- **Simple solids and sectional views:** Sectional drawing shows internal features by imagining the object cut by a cutting plane. Section lines indicate the cut surface and help communicate hidden details clearly.

### Quick revision
- Unit 6 focuses on: Principles of orthographic projection, First/third angle concepts, Projection of points, lines and planes, Simple solids and sectional views.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications