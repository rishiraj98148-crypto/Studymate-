# Engineering Mathematics I

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Set, Functions and Graphs

### Key points
- **Cardinality and power set:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Set algebra and De Morgan’s laws:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Real numbers, intervals and absolute value:** Real numbers include rational and irrational numbers. An interval describes a continuous range of real numbers, while |x| gives the distance of x from zero.
- **Relations, domain and range:** A relation associates elements of one set with another. The domain is the set of allowed input values and the range is the set of output values actually obtained.
- **Types of functions; exponential and logarithmic graphs:** An exponential function has the variable in the exponent, while a logarithm is its inverse operation. Important laws include log(ab)=log a+log b and log(a/b)=log a−log b for valid positive arguments.

### Quick revision
- Unit 1 focuses on: Cardinality and power set, Set algebra and De Morgan’s laws, Real numbers, intervals and absolute value, Relations, domain and range.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Trigonometry

### Key points
- **Basic identities and conditional identities:** Important identities include sin²θ+cos²θ=1, 1+tan²θ=sec²θ and 1+cot²θ=cosec²θ. Conditional identities are obtained by applying the given relation together with these standard identities.
- **General solutions of sin x=k, cos x=k, tan x=k:** For trigonometric equations, first find the principal angle and then include all angles having the same trigonometric value. The general solution depends on the period: 2π for sine and cosine and π for tangent.
- **Inverse circular functions:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Sine, cosine and projection laws:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Half-angle and tangent laws; area and solution of triangles:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 2 focuses on: Basic identities and conditional identities, General solutions of sin x=k, cos x=k, tan x=k, Inverse circular functions, Sine, cosine and projection laws.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Calculus

### Key points
- **Limits and indeterminate forms:** A limit describes the value that a function approaches as the independent variable approaches a particular value. Limits are the foundation of continuity and differentiation and are evaluated by direct substitution, factorization or other appropriate algebraic methods.
- **Continuity and discontinuity:** A function is continuous at x=a when f(a) exists, lim(x→a)f(x) exists, and both values are equal. A discontinuity occurs when one or more of these conditions fails.
- **Derivative and its geometric/physical meaning:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **Rules and derivatives of trigonometric, parametric and implicit functions:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Higher derivatives:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **Basic integration, substitution, integration by parts and definite integrals:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.

### Quick revision
- Unit 3 focuses on: Limits and indeterminate forms, Continuity and discontinuity, Derivative and its geometric/physical meaning, Rules and derivatives of trigonometric, parametric and implicit functions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Algebra

### Key points
- **Arithmetic, geometric and harmonic progressions:** In an arithmetic progression consecutive terms differ by a constant d. In a geometric progression consecutive terms have a constant ratio r. A harmonic progression is formed when the reciprocals of its terms form an arithmetic progression.
- **Sums of natural numbers, squares and cubes:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Permutations and combinations:** Permutation counts ordered arrangements, while combination counts selections where order does not matter. The standard formulas are nPr=n!/(n−r)! and nCr=n!/[r!(n−r)!].
- **Binomial theorem and general/middle/free terms:** The binomial theorem expands (a+b)ⁿ into terms containing binomial coefficients. The general term is Tᵣ₊₁=nCr aⁿ⁻ʳ bʳ, which is used to find specific or middle terms.
- **Expansion for any index; exponential and logarithmic series:** An exponential function has the variable in the exponent, while a logarithm is its inverse operation. Important laws include log(ab)=log a+log b and log(a/b)=log a−log b for valid positive arguments.

### Quick revision
- Unit 4 focuses on: Arithmetic, geometric and harmonic progressions, Sums of natural numbers, squares and cubes, Permutations and combinations, Binomial theorem and general/middle/free terms.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Coordinate Geometry

### Key points
- **Straight-line forms and general equation:** A straight line may be written as y=mx+c, y−y₁=m(x−x₁), or ax+by+c=0. The slope m describes the inclination of the line and is useful for coordinate geometry and surveying calculations.
- **Angle between lines and angle bisectors:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Pair of lines and conditions:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Circle: standard, central and general forms:** A circle with centre (h,k) and radius r has equation (x−h)²+(y−k)²=r². The general form is x²+y²+Dx+Ey+F=0, from which centre and radius can be obtained by completing squares.
- **Tangent and normal; condition of tangency:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 5 focuses on: Straight-line forms and general equation, Angle between lines and angle bisectors, Pair of lines and conditions, Circle: standard, central and general forms.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications