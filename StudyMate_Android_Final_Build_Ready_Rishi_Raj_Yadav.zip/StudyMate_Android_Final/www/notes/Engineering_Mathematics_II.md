# Engineering Mathematics II

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Algebra

### Key points
- **Polynomial and quadratic equations:** A quadratic equation has the form ax² + bx + c = 0, where a ≠ 0. Its roots are x = (-b ± √(b²−4ac))/(2a). The discriminant D = b²−4ac determines whether the roots are real and distinct, real and equal, or complex.
- **Complex numbers, modulus, conjugate and polar form:** A complex number is written as z = a + ib, where i² = −1. Its modulus is |z| = √(a²+b²) and its conjugate is a−ib. In polar form, z = r(cosθ + i sinθ), which is useful for multiplication, division and powers.
- **De Moivre’s theorem and cube roots of unity:** De Moivre’s theorem states (cosθ + i sinθ)^n = cos(nθ) + i sin(nθ). It is used to find powers and roots of complex numbers and to simplify trigonometric expressions.
- **Matrices, determinants and inverse:** A matrix is a rectangular arrangement of numbers. Its order is given by rows × columns; matrices can be added or multiplied when their dimensions permit. For a 2×2 matrix [[a,b],[c,d]], the determinant is ad−bc, and a non-zero determinant indicates that an inverse exists.
- **Linear equations by Cramer/inverse/row methods:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Linear inequalities and graphical linear programming:** Linear programming finds the maximum or minimum value of an objective function subject to linear constraints. In the graphical method, plot the constraints, identify the feasible region, and test the corner points to obtain the optimum value.

### Quick revision
- Unit 1 focuses on: Polynomial and quadratic equations, Complex numbers, modulus, conjugate and polar form, De Moivre’s theorem and cube roots of unity, Matrices, determinants and inverse.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Conic Sections

### Key points
- **Parabola: standard and shifted forms:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Ellipse and hyperbola: standard/shifted forms:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Centre, vertices, foci and directrices:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 2 focuses on: Parabola: standard and shifted forms, Ellipse and hyperbola: standard/shifted forms, Centre, vertices, foci and directrices.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Geometry

### Key points
- **3-D Cartesian coordinates:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Distance and section formulae:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Direction cosines/ratios and projections:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Equations of planes and normal/intercept forms:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Angle between planes and perpendicular distance:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 3 focuses on: 3-D Cartesian coordinates, Distance and section formulae, Direction cosines/ratios and projections, Equations of planes and normal/intercept forms.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Vectors

### Key points
- **Vector notation and representation:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Modulus and direction cosines:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Vector algebra and dependence/coplanarity:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Scalar product and applications:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Vector product and straight-line vector equation:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.

### Quick revision
- Unit 4 focuses on: Vector notation and representation, Modulus and direction cosines, Vector algebra and dependence/coplanarity, Scalar product and applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Statistics and Probability

### Key points
- **Mean, median, mode, quartiles and percentiles:** Statistics summarizes observed data using measures such as mean, median, mode, variance and standard deviation. These measures help describe survey observations and assess their spread.
- **Range, mean deviation, quartile deviation and standard deviation:** Statistics summarizes observed data using measures such as mean, median, mode, variance and standard deviation. These measures help describe survey observations and assess their spread.
- **Skewness, correlation and regression:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Basic probability laws and mutually exclusive events:** Statistics deals with collecting, organizing and interpreting numerical data. Mean, median, mode and measures of dispersion summarize observations, while probability expresses the likelihood of an event and ranges from 0 to 1.
- **Random/discrete variables; binomial and normal distributions:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 5 focuses on: Mean, median, mode, quartiles and percentiles, Range, mean deviation, quartile deviation and standard deviation, Skewness, correlation and regression, Basic probability laws and mutually exclusive events.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications