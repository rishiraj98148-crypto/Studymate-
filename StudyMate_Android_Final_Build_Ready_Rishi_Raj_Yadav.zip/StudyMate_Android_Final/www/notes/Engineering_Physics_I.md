# Engineering Physics I

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Mechanics

### Key points
- **Units and measurement; dimensional formula:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **Scalars and vectors; vector resolution:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Kinematics and projectile motion:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Newton’s laws, momentum, friction:** Newton’s laws describe the relation between force and motion. The second law gives F = ma, so acceleration is proportional to the net force and inversely proportional to mass. Free-body diagrams help apply the laws to engineering problems.
- **Uniform circular motion and centripetal force:** Mechanics studies motion and the forces that produce or change motion. Basic quantities include displacement, velocity, acceleration, force and momentum, with Newton’s laws providing the main framework.
- **Work, energy and power:** Work is done when a force produces displacement in its direction; for a constant force W = Fs cosθ. Kinetic energy is ½mv² and gravitational potential energy near Earth is mgh. The work–energy principle relates net work to change in kinetic energy.
- **Gravity, satellites and escape/orbital velocity:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **Simple harmonic motion:** Mechanics studies motion and the forces that produce or change motion. Basic quantities include displacement, velocity, acceleration, force and momentum, with Newton’s laws providing the main framework.
- **Rotation of rigid bodies, torque and moment of inertia:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.

### Quick revision
- Unit 1 focuses on: Units and measurement; dimensional formula, Scalars and vectors; vector resolution, Kinematics and projectile motion, Newton’s laws, momentum, friction.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Heat and Thermodynamics

### Key points
- **Temperature and quantity of heat:** Heat is energy transferred because of a temperature difference. For sensible heating, Q = mcΔT, while phase change uses Q = mL. Thermal concepts are important for understanding temperature change, expansion and heat transfer in engineering materials.
- **Phase change, latent heat and hygrometry:** Heat is energy transferred because of a temperature difference. For sensible heating, Q = mcΔT, while phase change uses Q = mL. Thermal concepts are important for understanding temperature change, expansion and heat transfer in engineering materials.
- **Thermal expansion:** Heat is energy transferred because of a temperature difference. For sensible heating, Q = mcΔT, while phase change uses Q = mL. Thermal concepts are important for understanding temperature change, expansion and heat transfer in engineering materials.
- **Conduction and radiation:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **Gas laws and kinetic theory:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **First/second laws and thermodynamic processes:** Thermodynamics studies heat, work and energy transformations. The first law expresses conservation of energy: heat supplied equals increase in internal energy plus work done by the system, with sign convention depending on the adopted convention.

### Quick revision
- Unit 2 focuses on: Temperature and quantity of heat, Phase change, latent heat and hygrometry, Thermal expansion, Conduction and radiation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Optics

### Key points
- **Geometrical optics and basic optical instruments:** Optics studies the behaviour of light, including reflection, refraction, interference and image formation. The laws and ray diagrams are used to determine image position, size and nature.
- **Wave nature/interference and diffraction concepts:** A wave transfers energy from one place to another without transporting matter as a whole. Important quantities include wavelength, frequency, period and wave speed, related by v=fλ.
- **Refraction and reflection applications:** Reflection is the return of light from a surface. The law of reflection states that the angle of incidence equals the angle of reflection, measured from the normal. Plane and spherical mirrors form images according to their geometry.

### Quick revision
- Unit 3 focuses on: Geometrical optics and basic optical instruments, Wave nature/interference and diffraction concepts, Refraction and reflection applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Magnetism

### Key points
- **Magnetic field and magnetic effects of current:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.
- **Basic electromagnetic concepts:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.
- **Applications and numerical relations:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.

### Quick revision
- Unit 4 focuses on: Magnetic field and magnetic effects of current, Basic electromagnetic concepts, Applications and numerical relations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications