# Engineering Physics II

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Electrostatics, Current and Electromagnetism

### Key points
- **Electric charge and field:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **Potential and capacitance:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **Current electricity and circuit relations:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **Magnetic field and electromagnetic effects:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.

### Quick revision
- Unit 1 focuses on: Electric charge and field, Potential and capacitance, Current electricity and circuit relations, Magnetic field and electromagnetic effects.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Waves and Optics

### Key points
- **Wave motion and basic wave parameters:** A wave transfers energy from one place to another without transporting matter as a whole. Important quantities include wavelength, frequency, period and wave speed, related by v=fλ.
- **Sound and wave applications:** A wave transfers energy from one place to another without transporting matter as a whole. Important quantities include wavelength, frequency, period and wave speed, related by v=fλ.
- **Reflection/refraction and optical systems:** Reflection is the return of light from a surface. The law of reflection states that the angle of incidence equals the angle of reflection, measured from the normal. Plane and spherical mirrors form images according to their geometry.
- **Interference/diffraction basics:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.

### Quick revision
- Unit 2 focuses on: Wave motion and basic wave parameters, Sound and wave applications, Reflection/refraction and optical systems, Interference/diffraction basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Properties of Matter

### Key points
- **Elasticity and stress-strain:** Properties of matter describe how materials respond to forces and changes in temperature or pressure. Important properties include elasticity, viscosity, surface tension, density and related mechanical behaviour.
- **Fluid properties and viscosity:** Properties of matter describe how materials respond to forces and changes in temperature or pressure. Important properties include elasticity, viscosity, surface tension, density and related mechanical behaviour.
- **Surface tension and capillarity:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **Engineering applications:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.

### Quick revision
- Unit 3 focuses on: Elasticity and stress-strain, Fluid properties and viscosity, Surface tension and capillarity, Engineering applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Modern Physics

### Key points
- **Relativity basics:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.
- **Quantum ideas and photoelectric effect:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **Atomic/nuclear physics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Radiation and semiconductor concepts:** This physics topic is explained through its physical quantity, governing law, units and practical application. For exams, state the law clearly, define the variables and show the required relation or diagram.

### Quick revision
- Unit 4 focuses on: Relativity basics, Quantum ideas and photoelectric effect, Atomic/nuclear physics, Radiation and semiconductor concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications