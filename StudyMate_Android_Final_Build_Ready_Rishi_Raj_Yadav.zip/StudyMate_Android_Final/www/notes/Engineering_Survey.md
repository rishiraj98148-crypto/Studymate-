# Engineering Survey

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction to Engineering Survey

### Key points
- **Purpose and types of engineering surveys:** Purpose and types of engineering surveys is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Reconnaissance and control:** Reconnaissance and control is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Construction survey workflow:** Construction survey workflow is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 1 focuses on: Purpose and types of engineering surveys, Reconnaissance and control, Construction survey workflow.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Route Survey

### Key points
- **Route reconnaissance and alignment:** Route reconnaissance and alignment is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Longitudinal/cross profiles:** Longitudinal/cross profiles is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Chainage and route setting out:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.

### Quick revision
- Unit 2 focuses on: Route reconnaissance and alignment, Longitudinal/cross profiles, Chainage and route setting out.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Curve

### Key points
- **Horizontal circular curves:** Horizontal circular curves is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Elements and setting-out methods:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Vertical curves basics:** Vertical curves basics is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 3 focuses on: Horizontal circular curves, Elements and setting-out methods, Vertical curves basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Area and Volume

### Key points
- **Area from coordinates and ordinates:** Area from coordinates and ordinates is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Volume by sections and contour methods:** A contour is a line joining points of equal elevation. Contour interval is the vertical difference between successive contours. Contours help represent relief and are used to determine slope, drainage patterns, profiles and approximate earthwork requirements.
- **Earthwork computation:** Earthwork computation is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 4 focuses on: Area from coordinates and ordinates, Volume by sections and contour methods, Earthwork computation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Site Survey

### Key points
- **Site selection and topographic detail:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Building/construction setting out:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Cut/fill and site control:** Cut/fill and site control is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 5 focuses on: Site selection and topographic detail, Building/construction setting out, Cut/fill and site control.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Hydrographic Survey

### Key points
- **Water-body survey purpose:** Water-body survey purpose is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Sounding and depth measurement:** Sounding and depth measurement is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Hydrographic plotting and applications:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].

### Quick revision
- Unit 6 focuses on: Water-body survey purpose, Sounding and depth measurement, Hydrographic plotting and applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications