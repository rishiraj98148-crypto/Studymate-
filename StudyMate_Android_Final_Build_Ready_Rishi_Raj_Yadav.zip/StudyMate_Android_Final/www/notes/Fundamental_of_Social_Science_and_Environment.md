# Fundamental of Social Science and Environment

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction to Society

### Key points
- **Society, community and social structure:** Society is a system of people, relationships, institutions, norms and shared practices. Social change refers to significant changes in these structures and relationships over time.
- **Culture and social institutions:** Society is a system of people, relationships, institutions, norms and shared practices. Social change refers to significant changes in these structures and relationships over time.

### Quick revision
- Unit 1 focuses on: Society, community and social structure, Culture and social institutions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Process of Social Change and Integration

### Key points
- **Social change factors:** Society is a system of people, relationships, institutions, norms and shared practices. Social change refers to significant changes in these structures and relationships over time.
- **Integration, inclusion and cohesion:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.

### Quick revision
- Unit 2 focuses on: Social change factors, Integration, inclusion and cohesion.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Challenges to Nepali Society

### Key points
- **Social inequality and exclusion:** Society is a system of people, relationships, institutions, norms and shared practices. Social change refers to significant changes in these structures and relationships over time.
- **Migration, population and development issues:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 3 focuses on: Social inequality and exclusion, Migration, population and development issues.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Basics of Governance System in Nepal

### Key points
- **Governance concepts:** Governance concerns the institutions, processes and rules through which public decisions are made and implemented. The topic is studied in the context specified for Nepal in the syllabus.
- **Federal, provincial and local levels:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.
- **Public participation and accountability:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 4 focuses on: Governance concepts, Federal, provincial and local levels, Public participation and accountability.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Sustainable Development and Community

### Key points
- **Development concepts and community participation:** Community development is a participatory process through which local people identify needs, mobilize resources and work toward improved social and economic conditions.
- **Local resource and development planning:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 5 focuses on: Development concepts and community participation, Local resource and development planning.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Resource Mobilization for Community Development

### Key points
- **Local resources:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.
- **Participation and mobilization methods:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 6 focuses on: Local resources, Participation and mobilization methods.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Environment Protection

### Key points
- **Environmental components:** The environment includes living and non-living components and the interactions among them. Environmental protection aims to reduce harmful impacts, conserve resources and maintain ecological functions for present and future needs.
- **Pollution and conservation:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.
- **Sustainable practices:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 7 focuses on: Environmental components, Pollution and conservation, Sustainable practices.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Disaster Risk Management

### Key points
- **Hazard, vulnerability and risk:** A hazard is a potentially damaging event or condition, while disaster occurs when impacts seriously disrupt a community beyond its capacity to cope. Disaster risk is influenced by hazard, exposure, vulnerability and capacity; risk management therefore includes prevention, preparedness, response and recovery.
- **Preparedness, mitigation, response and recovery:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 8 focuses on: Hazard, vulnerability and risk, Preparedness, mitigation, response and recovery.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Climate Change

### Key points
- **Causes and impacts:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.
- **Adaptation and mitigation:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.
- **Nepal context:** This topic explains an aspect of society, community development or environmental management covered by the syllabus. Learn the key concept, causes or processes, effects and practical measures or examples relevant to Nepal.

### Quick revision
- Unit 9 focuses on: Causes and impacts, Adaptation and mitigation, Nepal context.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications