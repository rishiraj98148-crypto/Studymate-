# Fundamental of Surveying and Geomatics

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Historical Background

### Key points
- **Development of surveying and geomatics:** Development of surveying and geomatics is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Historical instruments and mapping development:** Historical instruments and mapping development is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 1 focuses on: Development of surveying and geomatics, Historical instruments and mapping development.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Introduction to Surveying

### Key points
- **Definition, purpose and scope:** Definition, purpose and scope is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Basic surveying operations:** Basic surveying operations is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Surveying in geomatics and engineering:** Surveying in geomatics and engineering is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 2 focuses on: Definition, purpose and scope, Basic surveying operations, Surveying in geomatics and engineering.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Principles and Classifications

### Key points
- **Working from whole to part:** Working from whole to part is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Classification by purpose, instrument and method:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Plane and geodetic surveying:** Plane and geodetic surveying is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 3 focuses on: Working from whole to part, Classification by purpose, instrument and method, Plane and geodetic surveying.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Measurement Units

### Key points
- **Linear, angular and area units:** Linear, angular and area units is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Conversions and standard units:** Conversions and standard units is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 4 focuses on: Linear, angular and area units, Conversions and standard units.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Map Scale

### Key points
- **Statement, RF and graphical scales:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Scale selection and uses:** Scale selection and uses is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Scale conversion and accuracy:** Scale conversion and accuracy is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 5 focuses on: Statement, RF and graphical scales, Scale selection and uses, Scale conversion and accuracy.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Linear Measurements

### Key points
- **Chaining/taping concepts:** Chaining/taping concepts is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Distance corrections and field procedures:** Distance corrections and field procedures is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Obstacles and indirect measurement:** Obstacles and indirect measurement is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 6 focuses on: Chaining/taping concepts, Distance corrections and field procedures, Obstacles and indirect measurement.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Angular Measurements

### Key points
- **Bearings and azimuths:** Bearing expresses the direction of a survey line relative to a reference meridian. Included angles can be derived from bearings, while local attraction and magnetic declination must be considered when compass observations are used.
- **Compass and theodolite concepts:** Compass and theodolite concepts is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Angle measurement and reduction:** Bearing expresses the direction of a survey line relative to a reference meridian. Included angles can be derived from bearings, while local attraction and magnetic declination must be considered when compass observations are used.

### Quick revision
- Unit 7 focuses on: Bearings and azimuths, Compass and theodolite concepts, Angle measurement and reduction.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Map Reading

### Key points
- **Map symbols, grid and conventional signs:** Map symbols, grid and conventional signs is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Relief and coordinate information:** Relief and coordinate information is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Basic map interpretation:** Basic map interpretation is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.

### Quick revision
- Unit 8 focuses on: Map symbols, grid and conventional signs, Relief and coordinate information, Basic map interpretation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Measurement Errors

### Key points
- **Sources and types of errors:** Survey observations contain unavoidable errors. Accuracy describes closeness to the true value, while precision describes consistency among repeated observations. Random errors can be reduced through repeated observations and appropriate adjustment, whereas systematic errors require identification and correction.
- **Accuracy, precision and tolerances:** Accuracy, precision and tolerances is a syllabus topic that should be learned through its definition, main characteristics, working principle or procedure, and relevant engineering application. For the examination, prepare the key terms and the sequence or formula specifically associated with this topic.
- **Basic error treatment and checks:** Survey observations contain unavoidable errors. Accuracy describes closeness to the true value, while precision describes consistency among repeated observations. Random errors can be reduced through repeated observations and appropriate adjustment, whereas systematic errors require identification and correction.

### Quick revision
- Unit 9 focuses on: Sources and types of errors, Accuracy, precision and tolerances, Basic error treatment and checks.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications