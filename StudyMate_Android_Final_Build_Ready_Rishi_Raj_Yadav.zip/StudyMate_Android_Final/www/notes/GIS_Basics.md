# GIS Basics

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Database Management System

### Key points
- **Database concepts and data organization:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Tables, records and fields:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **Spatial database basics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].

### Quick revision
- Unit 1 focuses on: Database concepts and data organization, Tables, records and fields, Spatial database basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: GIS and Spatial Data Models

### Key points
- **GIS definition and components:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **Raster and vector models:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Spatial relationships and topology:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **Coordinate reference concepts:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.

### Quick revision
- Unit 2 focuses on: GIS definition and components, Raster and vector models, Spatial relationships and topology, Coordinate reference concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Spatial Data Acquisition and Preparation

### Key points
- **Digitizing and scanning:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **GNSS/remote sensing and survey data:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **Editing, georeferencing and data quality:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.

### Quick revision
- Unit 3 focuses on: Digitizing and scanning, GNSS/remote sensing and survey data, Editing, georeferencing and data quality.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Spatial Analysis and Applications

### Key points
- **Query and overlay concepts:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **Buffering and spatial analysis:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.
- **Map composition and GIS applications:** GIS stores, manages, analyses and displays information referenced to geographic locations. Spatial data commonly use vector features such as points, lines and polygons or raster cells; attribute data describe the properties of those spatial features.

### Quick revision
- Unit 4 focuses on: Query and overlay concepts, Buffering and spatial analysis, Map composition and GIS applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications