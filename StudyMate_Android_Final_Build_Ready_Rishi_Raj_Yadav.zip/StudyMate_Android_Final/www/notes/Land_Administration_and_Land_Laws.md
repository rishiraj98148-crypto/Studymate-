# Land Administration and Land Laws

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Introduction

### Key points
- **Land administration concept and functions:** Land administration deals with the processes and institutions that record, manage and provide information about land rights, restrictions, responsibilities and land use. It supports secure tenure and orderly land management.
- **Land information and institutional framework:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 1 focuses on: Land administration concept and functions, Land information and institutional framework.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Basics of Land Tenure and Rights

### Key points
- **Tenure types:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Ownership and use rights:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Rights, restrictions and responsibilities:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 2 focuses on: Tenure types, Ownership and use rights, Rights, restrictions and responsibilities.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Land Registration System

### Key points
- **Registration purpose and process:** Land registration formally records recognized rights in land and links those rights to identifiable parcels. Accurate survey records, supporting documents and consistent parcel identification are important for maintaining reliable registration records.
- **Title/parcel records:** A parcel is a defined unit of land that can be uniquely identified in a cadastral system. Parcel boundaries should be surveyed and recorded consistently so that the parcel can be linked to its map, register and relevant legal records.
- **Transaction and updating:** A land law topic should be studied through the purpose of the legal provision, the rights or duties it defines, the responsible authority and the procedure or restriction described in the syllabus.

### Quick revision
- Unit 3 focuses on: Registration purpose and process, Title/parcel records, Transaction and updating.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Land Valuation Basics

### Key points
- **Valuation purpose and principles:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Factors affecting land value:** A land law topic should be studied through the purpose of the legal provision, the rights or duties it defines, the responsible authority and the procedure or restriction described in the syllabus.

### Quick revision
- Unit 4 focuses on: Valuation purpose and principles, Factors affecting land value.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Land Conflicts and Their Resolutions

### Key points
- **Common land conflicts:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Mediation, administrative and legal approaches:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 5 focuses on: Common land conflicts, Mediation, administrative and legal approaches.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Basics of Land Management

### Key points
- **Land-use planning:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Land information and development control:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 6 focuses on: Land-use planning, Land information and development control.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Land Reform

### Key points
- **Concept and objectives:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Land reform approaches and Nepal context:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 7 focuses on: Concept and objectives, Land reform approaches and Nepal context.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Land Valuation

### Key points
- **Valuation methods and market factors:** A land law topic should be studied through the purpose of the legal provision, the rights or duties it defines, the responsible authority and the procedure or restriction described in the syllabus.
- **Assessment and documentation:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 8 focuses on: Valuation methods and market factors, Assessment and documentation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: LIS and Modernizing Land Administration Services

### Key points
- **Land Information System:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Digital services and data integration:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.
- **Modern land administration:** Land administration deals with the processes and institutions that record, manage and provide information about land rights, restrictions, responsibilities and land use. It supports secure tenure and orderly land management.

### Quick revision
- Unit 9 focuses on: Land Information System, Digital services and data integration, Modern land administration.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 10: Land Laws in Nepal

### Key points
- **Key land-related legal concepts:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.
- **Land registration, ownership and transactions:** Land registration formally records recognized rights in land and links those rights to identifiable parcels. Accurate survey records, supporting documents and consistent parcel identification are important for maintaining reliable registration records.
- **Institutional/legal compliance:** This topic concerns the administration, management or legal framework of land. Learn the responsible institutions, main procedures, rights and restrictions using the terminology given in the syllabus.

### Quick revision
- Unit 10 focuses on: Key land-related legal concepts, Land registration, ownership and transactions, Institutional/legal compliance.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications