# Land Development and CAD – Semester 4 Notes
Course: EG 2204 GE

## Unit 1: Starting New / Opening Existing Drawing
A CAD drawing can be started from scratch, wizard or template. Drafting aids help control drawing behavior.

### Basic Interface
Important elements include screen layout, menus, icons, command line, dialog boxes and toggles. Preferences, units, scale, model-view setup and drawing limits should be configured according to the project.

## Unit 2: Drawing Commands
### Coordinate Input
Coordinates can be entered using directive, absolute, relative and polar forms. Coordinate method controls where geometry is created.

### Basic Geometry
Common commands/topics in the syllabus include point, line, polyline, multiline, construction line, circle, arc, ellipse, donut, polygon, rectangle, spline and solids.

### Hatching
Hatching fills a closed area with a selected pattern and is used to distinguish materials/regions in drawings.

### Text and Dimensions
Text communicates labels and notes. Dimensions communicate measured sizes using dimension lines, extension lines, arrows and numerical values.

## Unit 3: Modify
Main modification operations listed include:
- Selection
- Erase
- Trim
- Break
- Copy
- Mirror
- Offset
- Array
- Move
- Rotate
- Scale
- Stretch
- Lengthen
- Extend
- Chamfer
- Fillet

These commands modify existing geometry without redrawing it from the beginning.

## Unit 4: Features
### Layers
Layers organize drawing objects by properties such as visibility and graphical characteristics. Match/change properties helps standardize object appearance.

### Measure and Inquiry
Measurement/inquiry commands provide information such as distances, areas and object properties.

### Viewports and Templates
Model-space viewports and template drawings support consistent project presentation and repeated setup.

### Script Tiles and Drawing Exchange
The syllabus includes use of script tiles and exchange/conversion between drawing formats.

## Unit 5: Application of CAD and LD Software
Workflow topics include:
1. Create projects.
2. Plot coordinates from a file and create point groups.
3. Create layers with different properties from point groups.
4. Generate contours.
5. Create alignment, profile and cross-section.
6. Calculate excavation/filling quantities from cross-sections.
7. Create a map and connect a shapefile to Land Development software.
8. Extract coordinates from an existing civil drawing.

### Survey Data to CAD – General Workflow
Coordinate file → import/plot points → organize point groups/layers → draw features → create surface/contours → alignment/profile/cross-section → quantity work → layout/plot.

## Unit 6: Plotters and Plotting
Topics include symbols and legends, designing and layout, export and print.

A good plotting layout should contain the required map/drawing area, title information, scale where appropriate, legend/symbols and other project information.

## Exam Focus
Coordinate input, basic drawing commands, modify commands, layers, hatching, dimensions, point import, contours, alignment/profile/cross-section, quantity calculation and plotting are high-value revision topics.