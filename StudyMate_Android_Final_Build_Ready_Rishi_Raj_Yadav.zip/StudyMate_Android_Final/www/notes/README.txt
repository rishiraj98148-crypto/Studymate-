# StudyMate — Semester 1–6 Direct Notes

This package contains subject-wise direct study notes for Diploma/Geomatics Engineering Semesters 1–6.

Reference approach:
- CTEVT syllabus supplied for this project is the primary syllabus basis.
- Arjun00/Arjun Chaudhary's public resource organization (semester → subject → notes) was used as a structural reference.
- The note wording in this package is original and is not copied verbatim from that site.

Semester 4:
- Existing detailed Semester 4 notes are preserved where present.
- The five Semester 4 subjects remain available through the existing app note loader.

How to use:
1. Extract the ZIP.
2. Open `index.html` in SPCK Preview/browser.
3. Select Semester → Subject → Unit → Notes.
