# Survey Instruments Concepts

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Survey Instruments

### Key points
- **Ranging and chaining equipment:** Survey instruments are selected according to the quantity to be measured, required accuracy and field conditions. Correct centering, levelling, orientation, observation and recording are essential for reliable survey results.
- **Distance measurement instruments:** Survey instruments are selected according to the quantity to be measured, required accuracy and field conditions. Correct centering, levelling, orientation, observation and recording are essential for reliable survey results.
- **Compass and bearings:** Bearing expresses the direction of a survey line relative to a reference meridian. Included angles can be derived from bearings, while local attraction and magnetic declination must be considered when compass observations are used.
- **Plane table and theodolite basics:** Survey instruments are selected according to the quantity to be measured, required accuracy and field conditions. Correct centering, levelling, orientation, observation and recording are essential for reliable survey results.
- **Levelling instruments:** Levelling determines differences in elevation between points. A level instrument provides a horizontal line of sight, and staff readings are used to compute reduced levels. Common checks include the arithmetic relation ΣBS−ΣFS = last RL−first RL.
- **EDM/total station and GNSS overview:** A total station combines electronic angle measurement, electronic distance measurement and onboard computation. It can observe points, calculate coordinates and store field data, making it useful for topographic, cadastral and engineering surveys.

### Quick revision
- Unit 1 focuses on: Ranging and chaining equipment, Distance measurement instruments, Compass and bearings, Plane table and theodolite basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications