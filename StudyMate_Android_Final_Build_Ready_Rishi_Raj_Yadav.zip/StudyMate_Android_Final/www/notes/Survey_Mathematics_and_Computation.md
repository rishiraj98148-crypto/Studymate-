# Survey Mathematics and Computation

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Partial Differentiation

### Key points
- **Partial derivatives and notation:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **First and higher partial derivatives:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **Engineering/survey computation applications:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 1 focuses on: Partial derivatives and notation, First and higher partial derivatives, Engineering/survey computation applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Numerical Integration

### Key points
- **Numerical integration concept:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.
- **Trapezoidal and Simpson-type rules:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Area/volume computation applications:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 2 focuses on: Numerical integration concept, Trapezoidal and Simpson-type rules, Area/volume computation applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Statistics

### Key points
- **Data presentation:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Central tendency and dispersion:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Survey data analysis:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 3 focuses on: Data presentation, Central tendency and dispersion, Survey data analysis.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Theory of Measurement Errors and Adjustments

### Key points
- **Random/systematic/gross errors:** Survey observations contain unavoidable errors. Accuracy describes closeness to the true value, while precision describes consistency among repeated observations. Random errors can be reduced through repeated observations and appropriate adjustment, whereas systematic errors require identification and correction.
- **Least-squares concept:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Observation adjustment and residuals:** Survey observations contain unavoidable errors. Accuracy describes closeness to the true value, while precision describes consistency among repeated observations. Random errors can be reduced through repeated observations and appropriate adjustment, whereas systematic errors require identification and correction.

### Quick revision
- Unit 4 focuses on: Random/systematic/gross errors, Least-squares concept, Observation adjustment and residuals.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Survey Computation

### Key points
- **Coordinate and traverse computations:** A traverse is a sequence of connected survey lines for which lengths and directions are measured. In a closed traverse, angular and coordinate misclosures are checked and adjusted before final plotting.
- **Area and volume computations:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.
- **Practical numerical checks:** This mathematical topic develops a defined method or relationship used in calculation. Learn the definition, governing formula, conditions of use and the sequence of steps used to solve the related numerical problem.

### Quick revision
- Unit 5 focuses on: Coordinate and traverse computations, Area and volume computations, Practical numerical checks.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications