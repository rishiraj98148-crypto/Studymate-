# Topographical Survey – Semester 4 Notes
Course: EG 2205 GE

## Unit 1: Introduction to Topographical Survey
### Topographical Survey
A topographical survey collects and represents the location and elevation of natural and artificial features of an area.

### Planimetric and Altimetric Detail
Planimetric detail describes horizontal position/features. Altimetric detail describes elevation/relief information.

### Natural and Artificial Features
Natural features arise from natural processes, while artificial features are constructed or modified by people.

### Contour and Contour Interval
A contour is a line joining points of equal elevation. Contour interval is the vertical difference in elevation between successive contours.

### Methods of Topographical Surveying
The syllabus identifies:
- Ground survey method
- Aerial survey method

### Contour Survey
Factors deciding contour interval include the nature of terrain, map scale, purpose of survey and required detail.

Methods:
- Direct contouring: points on a required contour are located directly in the field.
- Indirect contouring: elevations are observed at selected points and contours are later interpolated/plotted.

### Characteristics of Contours
Important principles include: contours join equal elevations; their spacing indicates slope conditions; they form characteristic patterns over different terrain; and contours generally do not intersect each other under ordinary terrain representation.

### Uses of Contours
Contours help understand relief, slope, drainage patterns and terrain for engineering planning and design.

## Unit 2: Plane Table (PT) Surveying
### Graphical Surveying
Graphical surveying records observations by plotting details directly on the drawing sheet. Plane tabling is a major graphical surveying method.

### Plottable Error
Plottable error is the error in a plotted position that becomes significant at the map scale.

### Accessories
- Plane table
- Alidade: simple and telescopic types
- Plumb bob
- Plane table level
- U-fork
- Magnetic compass
- Clinometer

Equipment should be checked and adjusted before field work. A proper plane-table sheet is prepared for plotting.

### Control Net and Auxiliary Points
A control net provides reference stations for survey work. Auxiliary points help extend/control observations where necessary.

### Setting Up
1. Stabilization – firmly set the table.
2. Centering – place the plotted station over the ground station.
3. Leveling – make the board level.
4. Orientation – align the table with the required reference direction.

### Methods of Plane Tabling
**Radiation:** rays are drawn from one station to different details and distances are plotted.

**Intersection:** directions from two known stations intersect at the detail point.

**Traversing:** successive stations are occupied and connected to form a traverse while details are plotted.

**Resection:** the position of an unknown station is determined from known plotted points. The syllabus includes two-point and three-point problems and methods such as Lehmann's rules, Bessel's method and tracing paper method.

### Danger Circle
The danger circle is a geometric condition associated with resection in which the configuration of known points can make the station determination unreliable or sensitive.

### Field Work
Preparation → reconnaissance → picking/selecting details → observation and plotting → checking.

### Errors
Errors may result from poor centering, leveling, orientation, sighting, plotting, unstable setup or incorrect distance/detail recording.

### Advantages
Plane table allows field observation and plotting together and gives a direct graphical view of the survey.

### Disadvantages
Accuracy can be affected by weather, poor setup, plotting limitations and unsuitable conditions. It is less suitable where high precision numerical observation is required.

## Unit 3: Tacheometric Surveying
### Introduction
Tacheometry is a surveying method in which distances and/or elevation differences are determined indirectly from angular and staff observations.

### Instruments
The syllabus includes instruments used in tachometry and methods based on stadia, tangential and subtense-bar systems.

### Stadia System
The stadia method uses staff intercept and instrument constants to obtain distance.

For the common horizontal line-of-sight form:
D = K s + C
where D is distance, s is staff intercept, K is multiplying constant and C is additive constant.

For inclined sight with staff vertical, the appropriate horizontal distance and vertical/elevation components are computed using the observed vertical angle and the instrument constants.

### Instrumental Constants
K and C are determined by calibration/known-distance observations according to the instrument and method.

### Tangential Method
Distance/elevation formulas depend on the observed vertical angles. The syllabus includes:
- both angles of elevation,
- both angles of depression,
- one angle of elevation and one angle of depression.

### Subtense Bar Method
A subtense bar of known geometry is observed from the instrument and distance is derived from the subtended angle using the method's distance relationship.

### Errors in Tacheometry
Possible errors include instrument/setup errors, staff reading errors, angular observation errors, refraction and incorrect constants.

### Survey Procedure
Reconnaissance → setup and orientation → staff observation/angle measurement → record data → compute distance/elevation → check and plot.

## Unit 4: Numerical Survey using Digital Instruments
### EDM
Electronic Distance Measurement determines distance electronically using electromagnetic signals.

### Total Station
A total station integrates electronic angle measurement and EDM with onboard computation/data recording. It is widely used for numerical topographic, cadastral and engineering data capture.

### GNSS
GNSS provides position using satellite observations. It is useful for control establishment and spatial data capture when suitable satellite visibility and survey procedures are available.

## Practical Focus
Indoor: map compilation.

Outdoor:
1. Establish controls for plane table.
2. Plane table traverse and adjustment.
3. Large-scale topographical mapping by plane table at 1:1000/1:500.
4. Plan numerical surveying: equipment preparation, field-data organization, calculation/adjustment, plotting/drawing and area calculation from numerical data.
5. Numerical survey field work: reconnaissance and observation/data capture for topographical/cadastral/engineering mapping at 1:500.