# Workshop Practice I

## Detailed Notes

These notes follow the unit and topic structure of the supplied CTEVT syllabus. Use them together with the official syllabus and prescribed textbook.

## Unit 1: Unit 1

### Key points
- **Bench work and basic workshop practice:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 1 focuses on: Bench work and basic workshop practice.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Unit 2

### Key points
- **Lying tools and their uses:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 2 focuses on: Lying tools and their uses.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Unit 3

### Key points
- **Cutting tools:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 3 focuses on: Cutting tools.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Unit 4

### Key points
- **Measuring instruments:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 4 focuses on: Measuring instruments.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Unit 5

### Key points
- **Rivet and riveting:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 5 focuses on: Rivet and riveting.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Unit 6

### Key points
- **Solder and soldering:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 6 focuses on: Solder and soldering.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Unit 7

### Key points
- **Shear and shearing:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 7 focuses on: Shear and shearing.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Unit 8

### Key points
- **Bend and bending:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 8 focuses on: Bend and bending.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Unit 9

### Key points
- **Power tools:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 9 focuses on: Power tools.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 10: Unit 10

### Key points
- **Sheet metal work:** Workshop practice develops practical skills through safe use of tools, materials and workshop procedures. For each practical, study the purpose, tools or machines, sequence of operations, precautions and expected result.

### Quick revision
- Unit 10 focuses on: Sheet metal work.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications