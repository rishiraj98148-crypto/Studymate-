# Applied Nepali

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: सञ्चारात्मक नेपाली भाषा र नेपाली व्याकरण

### Key points
- **भाषिक भेदको परिचय:** भाषिक भेदको परिचय is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **वर्णको परिचय र वर्णविन्यास:** वर्णको परिचय र वर्णविन्यास is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **शब्द भण्डार र शब्द रूपायन:** शब्द भण्डार र शब्द रूपायन is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **वाक्य संश्लेषण र वाक्य विश्लेषण:** वाक्य संश्लेषण र वाक्य विश्लेषण is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **पदसङ्गति:** पदसङ्गति is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: भाषिक भेदको परिचय, वर्णको परिचय र वर्णविन्यास, शब्द भण्डार र शब्द रूपायन, वाक्य संश्लेषण र वाक्य विश्लेषण.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: लेखन सीप

### Key points
- **बोधको ज्ञान:** बोधको ज्ञान is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **बुँदा लेखन र सारांश लेखन:** बुँदा लेखन र सारांश लेखन is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **संवाद तथा अनुच्छेद लेखन:** संवाद तथा अनुच्छेद लेखन is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **निमन्त्रणापत्र, सूचना, सम्पादकलाई चिठ्ठी, निवेदन, विज्ञापन र बधाई ज्ञापन:** निमन्त्रणापत्र, सूचना, सम्पादकलाई चिठ्ठी, निवेदन, विज्ञापन र बधाई ज्ञापन is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **निबन्ध लेखन:** निबन्ध लेखन is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **प्रतिवेदन लेखन:** प्रतिवेदन लेखन is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: बोधको ज्ञान, बुँदा लेखन र सारांश लेखन, संवाद तथा अनुच्छेद लेखन, निमन्त्रणापत्र, सूचना, सम्पादकलाई चिठ्ठी, निवेदन, विज्ञापन र बधाई ज्ञापन.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: कृति/पाठको परिचय लेख्ने अभ्यास

### Key points
- **कृति/पाठको परिचय लेख्ने अभ्यास:** कृति/पाठको परिचय लेख्ने अभ्यास is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **कृति समीक्षा:** कृति समीक्षा is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **कथा खण्ड:** कथा खण्ड is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **निबन्ध खण्ड:** निबन्ध खण्ड is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **कविता खण्ड:** कविता खण्ड is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **एकाङ्की:** एकाङ्की is studied in this unit as part of Applied Nepali. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: कृति/पाठको परिचय लेख्ने अभ्यास, कृति समीक्षा, कथा खण्ड, निबन्ध खण्ड.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
