# Computer Application

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction to Computers

### Key points
- **History and generations of computers:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Types of computers:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Hardware and software concepts:** Hardware and software concepts is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: History and generations of computers, Types of computers, Hardware and software concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Hardware Components

### Key points
- **Major blocks of a digital computer:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Input and output devices:** Input and output devices is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **CPU and memory: RAM, ROM, PROM, EPROM:** CPU and memory: RAM, ROM, PROM, EPROM is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Auxiliary storage: magnetic, optical and flash storage:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.

### Quick revision
- Unit 2 focuses on: Major blocks of a digital computer, Input and output devices, CPU and memory: RAM, ROM, PROM, EPROM, Auxiliary storage: magnetic, optical and flash storage.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Operating System Software

### Key points
- **Importance and functions of OS:** Importance and functions of OS is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **MS-DOS, Windows, Unix and Linux:** MS-DOS, Windows, Unix and Linux is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **File, device and memory management:** File, device and memory management is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Internal/external commands and file/folder management:** Internal/external commands and file/folder management is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Importance and functions of OS, MS-DOS, Windows, Unix and Linux, File, device and memory management, Internal/external commands and file/folder management.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Application Packages

### Key points
- **Text editors:** Text editors is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Microsoft Word: editing, formatting, tables and graphics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Microsoft Excel: data, formulas, calculations and charts:** Microsoft Excel: data, formulas, calculations and charts is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Database management and Microsoft Access:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Microsoft PowerPoint:** Microsoft PowerPoint is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Text editors, Microsoft Word: editing, formatting, tables and graphics, Microsoft Excel: data, formulas, calculations and charts, Database management and Microsoft Access.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Utility Programs

### Key points
- **Computer virus and antivirus:** A computer is an electronic system that accepts input, processes data, stores information and produces output. An operating system manages hardware resources and provides services for application programs and users.
- **Multimedia: audio, video and graphics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].

### Quick revision
- Unit 5 focuses on: Computer virus and antivirus, Multimedia: audio, video and graphics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Networks and Internet

### Key points
- **LAN, MAN and WAN:** LAN, MAN and WAN is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Bus, ring and star topologies:** Bus, ring and star topologies is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Hub, switch, modem and NIC:** Hub, switch, modem and NIC is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Network cabling and network OS:** A computer network connects devices so they can exchange data and share resources. The Internet is a global interconnection of networks that uses standard communication protocols to provide services such as web access and email.
- **Client-server, file/print sharing:** Client-server, file/print sharing is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **WWW, ISP, browsers, search engines and email:** WWW, ISP, browsers, search engines and email is studied in this unit as part of Computer Application. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: LAN, MAN and WAN, Bus, ring and star topologies, Hub, switch, modem and NIC, Network cabling and network OS.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
