# Engineering Chemistry I

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Language of Chemistry

### Key points
- **Chemical symbols and formulae:** Chemical symbols and formulae is studied in this unit as part of Engineering Chemistry I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Atomic and molecular mass:** The mole is the amount of substance containing Avogadro’s number of entities, approximately 6.022×10²³. Moles connect microscopic particles with measurable mass through n = m/M, where M is molar mass.
- **Mole concept and chemical equations:** The mole is the amount of substance containing Avogadro’s number of entities, approximately 6.022×10²³. Moles connect microscopic particles with measurable mass through n = m/M, where M is molar mass.
- **Basic chemical calculations:** Basic chemical calculations is studied in this unit as part of Engineering Chemistry I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Chemical symbols and formulae, Atomic and molecular mass, Mole concept and chemical equations, Basic chemical calculations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: General Chemistry

### Key points
- **Atomic structure and periodic concepts:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Chemical bonding:** Chemical bonding is the attraction that holds atoms or ions together. Ionic bonding involves electron transfer and electrostatic attraction, while covalent bonding involves sharing of electron pairs; metallic bonding involves delocalized electrons.
- **Acids, bases and salts:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Solutions, concentration and pH:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Chemical reactions and stoichiometry:** Chemical reactions and stoichiometry is studied in this unit as part of Engineering Chemistry I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Atomic structure and periodic concepts, Chemical bonding, Acids, bases and salts, Solutions, concentration and pH.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: System of Classification

### Key points
- **Periodic table and periodic trends:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Classification of elements:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Properties and common compounds:** Properties and common compounds is studied in this unit as part of Engineering Chemistry I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Engineering relevance of chemical materials:** Engineering relevance of chemical materials is studied in this unit as part of Engineering Chemistry I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Periodic table and periodic trends, Classification of elements, Properties and common compounds, Engineering relevance of chemical materials.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
