# Engineering Drawing I

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction of Engineering Drawing

### Key points
- **Purpose and importance of engineering drawing:** Purpose and importance of engineering drawing is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Drawing instruments and materials:** Drawing instruments and materials is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Standard drawing conventions:** Standard drawing conventions is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Purpose and importance of engineering drawing, Drawing instruments and materials, Standard drawing conventions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Lettering, scales and dimensions

### Key points
- **Engineering lettering:** Engineering lettering is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Plain, diagonal and comparative scales:** Plain, diagonal and comparative scales is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Dimensioning principles and conventions:** Dimensioning principles and conventions is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Engineering lettering, Plain, diagonal and comparative scales, Dimensioning principles and conventions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Geometrical constructions

### Key points
- **Bisecting lines and angles:** Bisecting lines and angles is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Regular polygons:** Regular polygons is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Tangent and related constructions:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 3 focuses on: Bisecting lines and angles, Regular polygons, Tangent and related constructions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Engineering Curve

### Key points
- **Ellipse, parabola and hyperbola constructions:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Cycloid and other standard engineering curves:** Cycloid and other standard engineering curves is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Ellipse, parabola and hyperbola constructions, Cycloid and other standard engineering curves.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Conic Sections

### Key points
- **Focus-directrix concept:** Focus-directrix concept is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Parabola, ellipse and hyperbola:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Construction methods:** Construction methods is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Focus-directrix concept, Parabola, ellipse and hyperbola, Construction methods.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Orthographic Projection

### Key points
- **Principles of orthographic projection:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **First/third angle concepts:** First/third angle concepts is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Projection of points, lines and planes:** A map projection transforms positions on the curved Earth to a plane. Because a curved surface cannot be flattened without distortion, projections are selected according to the purpose and region of mapping, considering distortion of distance, area, shape or direction.
- **Simple solids and sectional views:** Simple solids and sectional views is studied in this unit as part of Engineering Drawing I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: Principles of orthographic projection, First/third angle concepts, Projection of points, lines and planes, Simple solids and sectional views.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
