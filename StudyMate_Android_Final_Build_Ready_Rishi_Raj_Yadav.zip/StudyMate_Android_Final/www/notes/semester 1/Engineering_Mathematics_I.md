# Engineering Mathematics I

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Set, Functions and Graphs

### Key points
- **Cardinality and power set:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Set algebra and De Morgan’s laws:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Real numbers, intervals and absolute value:** Real numbers, intervals and absolute value is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Relations, domain and range:** Relations, domain and range is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Types of functions; exponential and logarithmic graphs:** An exponential function has the variable in the exponent, while a logarithm is its inverse operation. Important laws include log(ab)=log a+log b and log(a/b)=log a−log b for valid positive arguments.

### Quick revision
- Unit 1 focuses on: Cardinality and power set, Set algebra and De Morgan’s laws, Real numbers, intervals and absolute value, Relations, domain and range.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Trigonometry

### Key points
- **Basic identities and conditional identities:** Basic identities and conditional identities is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **General solutions of sin x=k, cos x=k, tan x=k:** General solutions of sin x=k, cos x=k, tan x=k is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Inverse circular functions:** Inverse circular functions is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Sine, cosine and projection laws:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Half-angle and tangent laws; area and solution of triangles:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 2 focuses on: Basic identities and conditional identities, General solutions of sin x=k, cos x=k, tan x=k, Inverse circular functions, Sine, cosine and projection laws.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Calculus

### Key points
- **Limits and indeterminate forms:** A limit describes the value that a function approaches as the independent variable approaches a particular value. Limits are the foundation of continuity and differentiation and are evaluated by direct substitution, factorization or other appropriate algebraic methods.
- **Continuity and discontinuity:** A function is continuous at x=a when f(a) exists, lim(x→a)f(x) exists, and both values are equal. A discontinuity occurs when one or more of these conditions fails.
- **Derivative and its geometric/physical meaning:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **Rules and derivatives of trigonometric, parametric and implicit functions:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Higher derivatives:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **Basic integration, substitution, integration by parts and definite integrals:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.

### Quick revision
- Unit 3 focuses on: Limits and indeterminate forms, Continuity and discontinuity, Derivative and its geometric/physical meaning, Rules and derivatives of trigonometric, parametric and implicit functions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Algebra

### Key points
- **Arithmetic, geometric and harmonic progressions:** Arithmetic, geometric and harmonic progressions is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Sums of natural numbers, squares and cubes:** Sums of natural numbers, squares and cubes is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Permutations and combinations:** Permutations and combinations is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Binomial theorem and general/middle/free terms:** Binomial theorem and general/middle/free terms is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Expansion for any index; exponential and logarithmic series:** An exponential function has the variable in the exponent, while a logarithm is its inverse operation. Important laws include log(ab)=log a+log b and log(a/b)=log a−log b for valid positive arguments.

### Quick revision
- Unit 4 focuses on: Arithmetic, geometric and harmonic progressions, Sums of natural numbers, squares and cubes, Permutations and combinations, Binomial theorem and general/middle/free terms.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Coordinate Geometry

### Key points
- **Straight-line forms and general equation:** Straight-line forms and general equation is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Angle between lines and angle bisectors:** Angle between lines and angle bisectors is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Pair of lines and conditions:** Pair of lines and conditions is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Circle: standard, central and general forms:** Circle: standard, central and general forms is studied in this unit as part of Engineering Mathematics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Tangent and normal; condition of tangency:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 5 focuses on: Straight-line forms and general equation, Angle between lines and angle bisectors, Pair of lines and conditions, Circle: standard, central and general forms.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
