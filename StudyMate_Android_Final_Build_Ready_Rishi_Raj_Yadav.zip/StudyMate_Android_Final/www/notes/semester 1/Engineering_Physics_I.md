# Engineering Physics I

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Mechanics

### Key points
- **Units and measurement; dimensional formula:** Units and measurement; dimensional formula is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Scalars and vectors; vector resolution:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Kinematics and projectile motion:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Newton’s laws, momentum, friction:** Newton’s laws describe the relation between force and motion. The second law gives F = ma, so acceleration is proportional to the net force and inversely proportional to mass. Free-body diagrams help apply the laws to engineering problems.
- **Uniform circular motion and centripetal force:** Uniform circular motion and centripetal force is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Work, energy and power:** Work is done when a force produces displacement in its direction; for a constant force W = Fs cosθ. Kinetic energy is ½mv² and gravitational potential energy near Earth is mgh. The work–energy principle relates net work to change in kinetic energy.
- **Gravity, satellites and escape/orbital velocity:** Gravity, satellites and escape/orbital velocity is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Simple harmonic motion:** Simple harmonic motion is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Rotation of rigid bodies, torque and moment of inertia:** Rotation of rigid bodies, torque and moment of inertia is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Units and measurement; dimensional formula, Scalars and vectors; vector resolution, Kinematics and projectile motion, Newton’s laws, momentum, friction.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Heat and Thermodynamics

### Key points
- **Temperature and quantity of heat:** Heat is energy transferred because of a temperature difference. For sensible heating, Q = mcΔT, while phase change uses Q = mL. Thermal concepts are important for understanding temperature change, expansion and heat transfer in engineering materials.
- **Phase change, latent heat and hygrometry:** Heat is energy transferred because of a temperature difference. For sensible heating, Q = mcΔT, while phase change uses Q = mL. Thermal concepts are important for understanding temperature change, expansion and heat transfer in engineering materials.
- **Thermal expansion:** Heat is energy transferred because of a temperature difference. For sensible heating, Q = mcΔT, while phase change uses Q = mL. Thermal concepts are important for understanding temperature change, expansion and heat transfer in engineering materials.
- **Conduction and radiation:** Conduction and radiation is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Gas laws and kinetic theory:** Gas laws and kinetic theory is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **First/second laws and thermodynamic processes:** Thermodynamics studies heat, work and energy transformations. The first law expresses conservation of energy: heat supplied equals increase in internal energy plus work done by the system, with sign convention depending on the adopted convention.

### Quick revision
- Unit 2 focuses on: Temperature and quantity of heat, Phase change, latent heat and hygrometry, Thermal expansion, Conduction and radiation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Optics

### Key points
- **Geometrical optics and basic optical instruments:** Geometrical optics and basic optical instruments is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Wave nature/interference and diffraction concepts:** Wave nature/interference and diffraction concepts is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Refraction and reflection applications:** Reflection is the return of light from a surface. The law of reflection states that the angle of incidence equals the angle of reflection, measured from the normal. Plane and spherical mirrors form images according to their geometry.

### Quick revision
- Unit 3 focuses on: Geometrical optics and basic optical instruments, Wave nature/interference and diffraction concepts, Refraction and reflection applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Magnetism

### Key points
- **Magnetic field and magnetic effects of current:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.
- **Basic electromagnetic concepts:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.
- **Applications and numerical relations:** Applications and numerical relations is studied in this unit as part of Engineering Physics I. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Magnetic field and magnetic effects of current, Basic electromagnetic concepts, Applications and numerical relations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
