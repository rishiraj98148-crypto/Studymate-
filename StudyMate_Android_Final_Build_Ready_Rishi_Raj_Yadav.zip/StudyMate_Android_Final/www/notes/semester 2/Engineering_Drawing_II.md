# Engineering Drawing II

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Projection Topic 1

### Key points
- **Axonometric projection:** A map projection transforms positions on the curved Earth to a plane. Because a curved surface cannot be flattened without distortion, projections are selected according to the purpose and region of mapping, considering distortion of distance, area, shape or direction.

### Quick revision
- Unit 1 focuses on: Axonometric projection.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Projection Topic 2

### Key points
- **Oblique drawing:** Oblique drawing is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Oblique drawing.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Projection Topic 3

### Key points
- **Isometric drawing:** Isometric drawing is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Isometric drawing.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Projection Topic 4

### Key points
- **True length and true shape of oblique lines:** True length and true shape of oblique lines is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: True length and true shape of oblique lines.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Projection Topic 5

### Key points
- **Intersection of line and plane:** Intersection of line and plane is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Intersection of line and plane.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Projection Topic 6

### Key points
- **Intersection of plane and plane:** Intersection of plane and plane is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: Intersection of plane and plane.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Projection Topic 7

### Key points
- **Projection of points/lines on surfaces of solids:** A map projection transforms positions on the curved Earth to a plane. Because a curved surface cannot be flattened without distortion, projections are selected according to the purpose and region of mapping, considering distortion of distance, area, shape or direction.

### Quick revision
- Unit 7 focuses on: Projection of points/lines on surfaces of solids.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Projection Topic 8

### Key points
- **Intersection of line and geometrical solids:** Intersection of line and geometrical solids is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 8 focuses on: Intersection of line and geometrical solids.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Projection Topic 9

### Key points
- **Sections:** Sections is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 9 focuses on: Sections.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 10: Projection Topic 10

### Key points
- **Intersection of planes and simple solids:** Intersection of planes and simple solids is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 10 focuses on: Intersection of planes and simple solids.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 11: Projection Topic 11

### Key points
- **Intersection between surfaces of solids:** Intersection between surfaces of solids is studied in this unit as part of Engineering Drawing II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 11 focuses on: Intersection between surfaces of solids.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
