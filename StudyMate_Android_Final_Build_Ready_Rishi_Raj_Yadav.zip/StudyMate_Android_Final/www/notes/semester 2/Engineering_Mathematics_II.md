# Engineering Mathematics II

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Algebra

### Key points
- **Polynomial and quadratic equations:** A quadratic equation has the form ax² + bx + c = 0, where a ≠ 0. Its roots are x = (-b ± √(b²−4ac))/(2a). The discriminant D = b²−4ac determines whether the roots are real and distinct, real and equal, or complex.
- **Complex numbers, modulus, conjugate and polar form:** A complex number is written as z = a + ib, where i² = −1. Its modulus is |z| = √(a²+b²) and its conjugate is a−ib. In polar form, z = r(cosθ + i sinθ), which is useful for multiplication, division and powers.
- **De Moivre’s theorem and cube roots of unity:** De Moivre’s theorem states (cosθ + i sinθ)^n = cos(nθ) + i sin(nθ). It is used to find powers and roots of complex numbers and to simplify trigonometric expressions.
- **Matrices, determinants and inverse:** A matrix is a rectangular arrangement of numbers. Its order is given by rows × columns; matrices can be added or multiplied when their dimensions permit. For a 2×2 matrix [[a,b],[c,d]], the determinant is ad−bc, and a non-zero determinant indicates that an inverse exists.
- **Linear equations by Cramer/inverse/row methods:** Linear equations by Cramer/inverse/row methods is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Linear inequalities and graphical linear programming:** Linear programming finds the maximum or minimum value of an objective function subject to linear constraints. In the graphical method, plot the constraints, identify the feasible region, and test the corner points to obtain the optimum value.

### Quick revision
- Unit 1 focuses on: Polynomial and quadratic equations, Complex numbers, modulus, conjugate and polar form, De Moivre’s theorem and cube roots of unity, Matrices, determinants and inverse.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Conic Sections

### Key points
- **Parabola: standard and shifted forms:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Ellipse and hyperbola: standard/shifted forms:** Conic sections are curves obtained from the intersection of a plane with a cone. The syllabus covers standard equations and geometric elements such as centre, vertex, focus and directrix; these are used to construct and analyse engineering curves.
- **Centre, vertices, foci and directrices:** Centre, vertices, foci and directrices is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Parabola: standard and shifted forms, Ellipse and hyperbola: standard/shifted forms, Centre, vertices, foci and directrices.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Geometry

### Key points
- **3-D Cartesian coordinates:** 3-D Cartesian coordinates is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Distance and section formulae:** Distance and section formulae is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Direction cosines/ratios and projections:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Equations of planes and normal/intercept forms:** Equations of planes and normal/intercept forms is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Angle between planes and perpendicular distance:** Angle between planes and perpendicular distance is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: 3-D Cartesian coordinates, Distance and section formulae, Direction cosines/ratios and projections, Equations of planes and normal/intercept forms.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Vectors

### Key points
- **Vector notation and representation:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Modulus and direction cosines:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Vector algebra and dependence/coplanarity:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.
- **Scalar product and applications:** Scalar product and applications is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Vector product and straight-line vector equation:** A vector has magnitude and direction and can be resolved into components. Dot product gives A·B = |A||B|cosθ, while cross product gives a vector perpendicular to both vectors. Vectors are widely used for forces, coordinates and three-dimensional surveying computations.

### Quick revision
- Unit 4 focuses on: Vector notation and representation, Modulus and direction cosines, Vector algebra and dependence/coplanarity, Scalar product and applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Statistics and Probability

### Key points
- **Mean, median, mode, quartiles and percentiles:** Mean, median, mode, quartiles and percentiles is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Range, mean deviation, quartile deviation and standard deviation:** Range, mean deviation, quartile deviation and standard deviation is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Skewness, correlation and regression:** Skewness, correlation and regression is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Basic probability laws and mutually exclusive events:** Statistics deals with collecting, organizing and interpreting numerical data. Mean, median, mode and measures of dispersion summarize observations, while probability expresses the likelihood of an event and ranges from 0 to 1.
- **Random/discrete variables; binomial and normal distributions:** Random/discrete variables; binomial and normal distributions is studied in this unit as part of Engineering Mathematics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Mean, median, mode, quartiles and percentiles, Range, mean deviation, quartile deviation and standard deviation, Skewness, correlation and regression, Basic probability laws and mutually exclusive events.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
