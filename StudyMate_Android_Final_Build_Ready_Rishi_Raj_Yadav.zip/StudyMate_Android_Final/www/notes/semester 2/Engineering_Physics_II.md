# Engineering Physics II

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Electrostatics, Current and Electromagnetism

### Key points
- **Electric charge and field:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **Potential and capacitance:** Potential and capacitance is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Current electricity and circuit relations:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **Magnetic field and electromagnetic effects:** Magnetism concerns magnetic fields and their interaction with moving charges, currents and magnetic materials. Field direction is represented by field lines, and magnetic effects are important in instruments, motors, generators and electromagnetic measurements.

### Quick revision
- Unit 1 focuses on: Electric charge and field, Potential and capacitance, Current electricity and circuit relations, Magnetic field and electromagnetic effects.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Waves and Optics

### Key points
- **Wave motion and basic wave parameters:** Wave motion and basic wave parameters is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Sound and wave applications:** Sound and wave applications is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Reflection/refraction and optical systems:** Reflection is the return of light from a surface. The law of reflection states that the angle of incidence equals the angle of reflection, measured from the normal. Plane and spherical mirrors form images according to their geometry.
- **Interference/diffraction basics:** Interference/diffraction basics is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Wave motion and basic wave parameters, Sound and wave applications, Reflection/refraction and optical systems, Interference/diffraction basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Properties of Matter

### Key points
- **Elasticity and stress-strain:** Elasticity and stress-strain is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Fluid properties and viscosity:** Fluid properties and viscosity is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Surface tension and capillarity:** Surface tension and capillarity is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Engineering applications:** Engineering applications is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Elasticity and stress-strain, Fluid properties and viscosity, Surface tension and capillarity, Engineering applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Modern Physics

### Key points
- **Relativity basics:** Relativity basics is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Quantum ideas and photoelectric effect:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **Atomic/nuclear physics:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Radiation and semiconductor concepts:** Radiation and semiconductor concepts is studied in this unit as part of Engineering Physics II. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Relativity basics, Quantum ideas and photoelectric effect, Atomic/nuclear physics, Radiation and semiconductor concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
