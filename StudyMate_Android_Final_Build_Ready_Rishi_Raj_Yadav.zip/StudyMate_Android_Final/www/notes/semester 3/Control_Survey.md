# Control Survey

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Levelling

### Key points
- **Benchmark and reduced level:** A benchmark is a fixed reference point whose elevation is known or adopted. Reduced level (RL) is the elevation of a point relative to the chosen datum. In levelling, staff readings are used to transfer RLs from a benchmark to other points.
- **HI and rise/fall methods:** In the height-of-instrument method, HI = RL + BS and RL = HI − staff reading. In the rise-and-fall method, a smaller consecutive staff reading indicates a rise and a larger reading indicates a fall; RL is updated from the previous point. Both methods provide arithmetic checks on levelling calculations.
- **Differential, profile and reciprocal levelling:** Levelling determines differences in elevation between points. A level instrument provides a horizontal line of sight, and staff readings are used to compute reduced levels. Common checks include the arithmetic relation ΣBS−ΣFS = last RL−first RL.
- **Levelling errors and adjustment:** Errors may arise from instrument collimation, staff reading, curvature and refraction, settlement, or field procedure. Reciprocal levelling helps reduce certain systematic effects. A closed levelling run is checked for misclosure and adjusted according to the adopted method.

### Quick revision
- Unit 1 focuses on: Benchmark and reduced level, HI and rise/fall methods, Differential, profile and reciprocal levelling, Levelling errors and adjustment.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Traverse

### Key points
- **Open/closed traverse:** A traverse is a sequence of connected survey lines for which lengths and directions are measured. In a closed traverse, angular and coordinate misclosures are checked and adjusted before final plotting.
- **Bearing and angle observations:** Bearing expresses the direction of a survey line relative to a reference meridian. Included angles can be derived from bearings, while local attraction and magnetic declination must be considered when compass observations are used.
- **Latitude/departure and coordinate computation:** For a line of length L and bearing θ, latitude is L cosθ and departure is L sinθ, with signs determined by the quadrant. Coordinates are obtained by adding the latitude and departure components successively to the starting northing and easting.
- **Traverse adjustment:** A traverse is a sequence of connected survey lines for which lengths and directions are measured. In a closed traverse, angular and coordinate misclosures are checked and adjusted before final plotting.

### Quick revision
- Unit 2 focuses on: Open/closed traverse, Bearing and angle observations, Latitude/departure and coordinate computation, Traverse adjustment.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Triangulation

### Key points
- **Triangulation principles and networks:** Triangulation establishes horizontal control using a network of triangles in which angles are measured and at least one side is known or determined. Good geometry, stable stations and accurate observations are essential.
- **Signals/stations and observations:** A triangulation station is a selected control point at which observations are made. Signals or marks make the station visible from other stations. Reconnaissance, stable monumentation, accurate centering and careful angle observation are essential for a reliable network.
- **Baseline and angular measurements:** A baseline is a carefully measured side of a triangulation network and provides the scale for the network. Horizontal angles are observed at control stations, and the observations are checked and adjusted before computing the coordinates of the stations.

### Quick revision
- Unit 3 focuses on: Triangulation principles and networks, Signals/stations and observations, Baseline and angular measurements.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Trilateration

### Key points
- **Distance-based control networks:** Trilateration establishes control from measured distances between stations. The geometry of the network should provide enough independent observations to determine the unknown point positions and permit checks on the measurements.
- **Electronic distance measurement:** EDM determines distance electronically by transmitting and receiving electromagnetic signals. The measured distance is affected by atmospheric conditions, instrument constants and observation geometry, so proper field procedures and corrections are important.
- **Network geometry and checks:** A good trilateration network has suitable geometry and sufficient redundant observations. Distance observations are checked for consistency, and computed coordinates are reviewed for misclosure and other discrepancies before final acceptance.

### Quick revision
- Unit 4 focuses on: Distance-based control networks, Electronic distance measurement, Network geometry and checks.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Resection and Intersection

### Key points
- **Position determination by resection:** Resection determines the position of an unknown occupied station from observations to known control points. Intersection determines an unknown point from observations made at known stations; both methods are useful when direct measurement to the point is difficult.
- **Intersection methods:** Intersection methods is studied in this unit as part of Control Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Applications and field checks:** Applications and field checks is studied in this unit as part of Control Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Position determination by resection, Intersection methods, Applications and field checks.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
