# Survey Instruments Concepts

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Survey Instruments

### Key points
- **Ranging and chaining equipment:** Ranging and chaining equipment is studied in this unit as part of Survey Instruments Concepts. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Distance measurement instruments:** Distance measurement instruments is studied in this unit as part of Survey Instruments Concepts. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Compass and bearings:** Bearing expresses the direction of a survey line relative to a reference meridian. Included angles can be derived from bearings, while local attraction and magnetic declination must be considered when compass observations are used.
- **Plane table and theodolite basics:** Plane table and theodolite basics is studied in this unit as part of Survey Instruments Concepts. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Levelling instruments:** Levelling determines differences in elevation between points. A level instrument provides a horizontal line of sight, and staff readings are used to compute reduced levels. Common checks include the arithmetic relation ΣBS−ΣFS = last RL−first RL.
- **EDM/total station and GNSS overview:** A total station combines electronic angle measurement, electronic distance measurement and onboard computation. It can observe points, calculate coordinates and store field data, making it useful for topographic, cadastral and engineering surveys.

### Quick revision
- Unit 1 focuses on: Ranging and chaining equipment, Distance measurement instruments, Compass and bearings, Plane table and theodolite basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
