# Survey Mathematics and Computation

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Partial Differentiation

### Key points
- **Partial derivatives and notation:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **First and higher partial derivatives:** Differentiation gives the rate of change of one quantity with respect to another. For example, d(x^n)/dx = nx^(n−1). It is used to find slopes, rates, maxima/minima and relationships between engineering quantities.
- **Engineering/survey computation applications:** Engineering/survey computation applications is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Partial derivatives and notation, First and higher partial derivatives, Engineering/survey computation applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Numerical Integration

### Key points
- **Numerical integration concept:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.
- **Trapezoidal and Simpson-type rules:** Trapezoidal and Simpson-type rules is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Area/volume computation applications:** Area/volume computation applications is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Numerical integration concept, Trapezoidal and Simpson-type rules, Area/volume computation applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Statistics

### Key points
- **Data presentation:** Data presentation is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Central tendency and dispersion:** Central tendency and dispersion is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Survey data analysis:** Survey data analysis is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Data presentation, Central tendency and dispersion, Survey data analysis.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Theory of Measurement Errors and Adjustments

### Key points
- **Random/systematic/gross errors:** Survey observations contain unavoidable errors. Accuracy describes closeness to the true value, while precision describes consistency among repeated observations. Random errors can be reduced through repeated observations and appropriate adjustment, whereas systematic errors require identification and correction.
- **Least-squares concept:** Least-squares concept is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Observation adjustment and residuals:** Survey observations contain unavoidable errors. Accuracy describes closeness to the true value, while precision describes consistency among repeated observations. Random errors can be reduced through repeated observations and appropriate adjustment, whereas systematic errors require identification and correction.

### Quick revision
- Unit 4 focuses on: Random/systematic/gross errors, Least-squares concept, Observation adjustment and residuals.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Survey Computation

### Key points
- **Coordinate and traverse computations:** A traverse is a sequence of connected survey lines for which lengths and directions are measured. In a closed traverse, angular and coordinate misclosures are checked and adjusted before final plotting.
- **Area and volume computations:** Area and volume computations is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Practical numerical checks:** Practical numerical checks is studied in this unit as part of Survey Mathematics and Computation. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Coordinate and traverse computations, Area and volume computations, Practical numerical checks.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
