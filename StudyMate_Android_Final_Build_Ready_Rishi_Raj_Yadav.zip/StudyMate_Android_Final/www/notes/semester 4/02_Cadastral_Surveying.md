# Cadastral Surveying – Semester 4 Notes
Course: EG 2202 GE

## Unit 1: Introduction
### Cadastre
A cadastre is an organized record/system of land parcels and associated information. In the Nepalese context, cadastral information includes map and land records such as terij, field book, plot register, title documents and database.

### Types of Cadastre
- Fiscal cadastre: primarily supports land valuation/tax-related purposes.
- Legal cadastre: supports legal identification and rights over parcels.
- Multipurpose cadastre: integrates cadastral information for several land-related purposes.

### Graphical and Digital Cadastre
Graphical cadastre stores/represents parcel information mainly through analogue graphical maps. Digital cadastre stores parcel geometry and related attributes in digital form, supporting computer-based management and updating.

### Parcel
A parcel is a defined unit of land that can be identified in the cadastral system. Parcel boundaries define its spatial extent.

### Parcel Boundary
A parcel boundary separates one land parcel from another or from other land/feature boundaries. The syllabus distinguishes general and fixed boundaries.

### Basic Principles
Cadastral surveying should identify parcels and boundaries systematically, maintain appropriate control, record observations and prepare reliable cadastral documents.

## Unit 2: Cadastral Surveying Techniques
Techniques listed in the syllabus include:
1. Annotation on existing map/image.
2. Chain/tape survey.
3. Compass survey.
4. Plane table alidade survey.
5. Total station survey.
6. Aerial photograph/orthophoto/satellite imagery/UAV.
7. GNSS technology.
8. Hybrid method.

Selection depends on required accuracy, terrain, available data, equipment, time and project requirements.

## Unit 3: Cadastral Maps
### Map Projection and Sheet Numbering
A cadastral map uses an appropriate projection/grid and systematic sheet identification so parcel positions can be mapped and referenced.

### Geodetic Control
Geodetic control points provide a reference framework for cadastral surveying and mapping.

### Types of Cadastral Maps
The syllabus includes index map, file map and parcel map. Their roles differ in indexing, record/file reference and detailed parcel representation.

### Plotting Error and Area Tolerance
Plotting error is the discrepancy introduced when measured/recorded parcel information is represented graphically. Tolerance provides an acceptable limit for discrepancies, including those affecting area computation.

### Parcel Numbering
Parcel numbering practices identify individual parcels systematically so that maps and land records can be linked.

## Unit 4: Graphical Cadastre
### Plane Table
A plane table is used to observe and plot details directly on a sheet in the field.

### Main Steps
Set up the table → center → level → orient → establish/observe control → survey details → plot boundaries → check and finalize.

### Inking and Tracing
Inking makes the prepared map lines permanent/clear. Tracing transfers required features from one drawing/map medium to another.

### Area Computation
Areas can be checked using graphical or coordinate-based methods. Independent checks help identify mistakes.

### Field Errors
Errors may arise from centering, leveling, orientation, plotting, observation and instrument handling. Field checks and repeated observations help control them.

## Unit 5: Digital Cadastre
### Data Acquisition
Prepare equipment and control → identify parcel boundaries → observe points with total station → record field information → download data → edit/organize → create map → prepare database and documents.

### Sketch and Map Making
A field sketch records the relation of parcel corners and nearby features. Digital mapping converts observed coordinates into parcel lines and map features.

### Database
A cadastral database links parcel geometry with attribute/record information so parcels can be queried and maintained.

### Satellite/Aerial Images
Satellite and aerial imagery can provide reference/background information and support cadastral development, subject to the required accuracy and workflow.

## Unit 6: Cadastral Surveying and Registration Procedure in Nepal
The syllabus sequence is:
1. Notification
2. Densification of control points
3. Adjudication – sporadic and systematic
4. Field book preparation
5. Land classification
6. Area computation
7. Registration of ownership
8. Registration system adopted in Nepal
9. Ownership certificate and other document preparation
10. Handing over of cadastral data

### Adjudication
Adjudication is the process of establishing/confirming parcel and ownership-related information through the prescribed procedure. Sporadic and systematic approaches differ in how the area/parcels are taken up.

### Field Book
The field book records survey observations and parcel-related field information used for cadastral preparation.

## Unit 7: Updating and Archiving
Main activities:
- Parcel subdivision
- Parcel history maintenance
- Plot register maintenance
- Database updating and maintenance
- Procedures at Survey offices

Updating keeps cadastral records consistent with approved changes. Archiving preserves previous and supporting cadastral documents for future reference.

## Unit 8: Cadastral Organizations and Roles in Nepal
The syllabus identifies:
- Concerned Ministry
- Survey Department
- Department of Land Reform and Management
- District Survey Offices
- District Land Reform and Revenue Offices
- Judicial and quasi-judicial bodies
- Local Governments

The syllabus also emphasizes the role of all three levels of government in cadastre development.

## Unit 9: Modern Cadastre
### 3D Cadastre
3D cadastre represents rights/interests in three-dimensional space where conventional 2D parcel representation is insufficient. The syllabus asks students to consider the introduction and current legal provisions in Nepal.

### International Examples
The syllabus includes Dutch Cadastre, LINZ and Singapore Cadastre as case studies.

### FIG Cadastral Vision 2014
The syllabus includes FIG Cadastral Vision 2014 and its achievement in Nepal.

### Future Cadastre / Vision 2034
Topics named by the syllabus include Survey Accurate Cadastre, Object Oriented Cadastre, Global Cadastre and 4D/5D cadastre.

## Practical Focus
1:500 cadastral data acquisition using plane table; digital cadastral survey using total station; parcel identification and boundary demarcation/layout; inking/tracing; area computation; documentation; parcel subdivision; data download; plotting/mapping; database and forms/reports.
