# Geodesy and Astronomy – Semester 4 Notes
Course: EG 2203 GE

## A. Elementary Geodesy
## Unit 1: Figure of the Earth
The Earth is not a perfect sphere. Surveying and geodesy use mathematical reference surfaces to represent its shape.

- Spheroid/ellipsoid: a mathematical surface used to approximate the Earth's shape.
- Geoid: an equipotential reference surface associated with mean sea level concept.
- Global spheroid: reference ellipsoid intended for broad/global applications.
- Local spheroid: reference surface selected for a particular region and its geodetic system.

Important ellipsoid parameters include semi-major axis and flattening (or related parameters).

## Unit 2: Coordinate Systems
Geographical coordinates express position using latitude and longitude. Rectangular/projected coordinates express position using perpendicular coordinate axes, commonly easting and northing in mapping.

Coordinate conversion means transforming position between geographical and rectangular/projected representations using the appropriate projection/parameters.

## Unit 3: Gravimetry
Gravimetry deals with measurement and study of Earth's gravity field. Important terms include gravity, gravity variation and related reference concepts. Gravity information is useful in geodesy and geophysical applications.

## B. Satellite Geodesy
## Unit 4: Introduction
Satellite geodesy uses artificial satellites and observations to determine positions, reference systems and Earth-related quantities.

## Unit 5: Satellite Orbits
Satellite types differ by purpose and orbit. Orbits may be classified by their geometry and altitude.

Kepler's laws describe planetary/satellite motion. Orbital elements are parameters used to define an orbit, such as its size, shape, orientation and position of the satellite on the orbit.

## Unit 6: Basics of GNSS
GNSS means Global Navigation Satellite System. Major systems named in the syllabus include GPS, GLONASS and Galileo.

Main components are:
- Space segment
- Control segment
- User segment

GNSS supports positioning, navigation and timing.

## Unit 7: GPS Signal Structure
The syllabus includes signal structure, pseudorange, P/C/A codes, carrier frequencies and data message.

Pseudorange is an apparent range derived from signal travel-time measurements and can include errors. Carrier-phase observations use the phase of the carrier signal and can support high-precision positioning when properly processed.

## Unit 8: Positioning Techniques
- Single point positioning: position determined using observations from one receiver.
- Relative/differential positioning: position determined relative to another known/reference receiver.
- Code phase: uses code observations.
- Carrier phase: uses carrier-phase observations.
- Static: receivers remain stationary during observation.
- Kinematic: receiver moves while observations are collected.
- RTK: real-time kinematic positioning using corrections for high-precision real-time results.
- Post-processing: observations are processed after field collection.

## Unit 9: Field Survey Procedures
General workflow: planning → reconnaissance → monumentation → observation → data checking → processing. GNSS observations are affected by errors, so planning and quality control are important.

## Unit 10: GPS Data Transformation
The syllabus includes geoid/ellipsoid, local/global datum, datum transformation and transformation parameters. Transformation is needed when coordinates from different reference systems must be related consistently.

## C. Astronomy
## Unit 11: Introduction
Astronomy is the study of celestial bodies and phenomena. The syllabus includes the solar system and Kepler's laws.

## Unit 12: Definitions of Terms
Important terms include terrestrial/celestial equator, great and small circles, zenith/nadir, horizon, celestial meridian, vertical circle, prime vertical, observer's meridian, cardinal points, ecliptic, equinoxes, solstices, altitude, co-altitude, declination, co-declination, latitude, co-latitude, hour angle, right ascension and azimuth.

## Unit 13: Spherical Trigonometry in Astronomy
The syllabus covers spherical triangles, the astronomical triangle, sine/cosine laws, right-angled spherical triangles, Napier's Rule and spherical excess.

## Practical Focus
Handheld GPS operation, positional data capture, navigation, route tracking, plotting GPS data, DGPS demonstration and post-processing are included in the practical syllabus.
