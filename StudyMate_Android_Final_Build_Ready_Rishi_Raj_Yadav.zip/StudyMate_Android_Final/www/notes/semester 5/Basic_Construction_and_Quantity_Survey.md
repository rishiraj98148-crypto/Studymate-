# Basic Construction and Quantity Survey

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction

### Key points
- **Construction and quantity surveying concept:** Quantity estimation determines the amount of work and materials required for a construction activity. Measurements are taken from drawings or field data, quantities are calculated using suitable geometric relations, and rates are then applied to prepare a cost estimate.
- **Role of surveyor in construction projects:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.

### Quick revision
- Unit 1 focuses on: Construction and quantity surveying concept, Role of surveyor in construction projects.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Construction Materials

### Key points
- **Cement, aggregates and concrete:** Construction materials and work items are selected according to their required properties and construction method. Proper proportioning, measurement, placement and curing are important for achieving the required strength and durability.
- **Bricks/blocks, steel and timber:** Bricks/blocks, steel and timber is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Properties and uses:** Properties and uses is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Cement, aggregates and concrete, Bricks/blocks, steel and timber, Properties and uses.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Building Construction

### Key points
- **Foundation, walls and floors:** Foundation, walls and floors is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Roofing and finishes:** Roofing and finishes is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Basic construction sequence:** Basic construction sequence is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Foundation, walls and floors, Roofing and finishes, Basic construction sequence.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Road Construction

### Key points
- **Road components and alignment:** Road components and alignment is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Earthwork and pavement basics:** Earthwork and pavement basics is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Drainage and construction considerations:** Drainage and construction considerations is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Road components and alignment, Earthwork and pavement basics, Drainage and construction considerations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Irrigation System

### Key points
- **Irrigation purpose and components:** Irrigation purpose and components is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Canals and basic structures:** Canals and basic structures is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Survey requirements:** Survey requirements is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Irrigation purpose and components, Canals and basic structures, Survey requirements.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: River Training Works

### Key points
- **River behaviour and training purpose:** River behaviour and training purpose is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Basic protection/training structures:** Basic protection/training structures is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: River behaviour and training purpose, Basic protection/training structures.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Water Supply System

### Key points
- **Sources and intake:** Sources and intake is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Conveyance, storage and distribution:** Conveyance, storage and distribution is studied in this unit as part of Basic Construction and Quantity Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Basic network components:** A computer network connects devices so they can exchange data and share resources. The Internet is a global interconnection of networks that uses standard communication protocols to provide services such as web access and email.

### Quick revision
- Unit 7 focuses on: Sources and intake, Conveyance, storage and distribution, Basic network components.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
