# Cadastral Surveying

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction

### Key points
- **Cadastre and cadastral surveying:** A cadastre is a parcel-based system that records information about land units, commonly including location, extent, ownership or rights and related records. Cadastral surveying establishes or updates parcel boundaries and produces maps and records used in land administration.
- **Fiscal, legal and multipurpose cadastre:** A cadastre is a parcel-based system that records information about land units, commonly including location, extent, ownership or rights and related records. Cadastral surveying establishes or updates parcel boundaries and produces maps and records used in land administration.
- **Graphical and digital cadastre:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Nepal cadastral components and records:** A cadastre is a parcel-based system that records information about land units, commonly including location, extent, ownership or rights and related records. Cadastral surveying establishes or updates parcel boundaries and produces maps and records used in land administration.

### Quick revision
- Unit 1 focuses on: Cadastre and cadastral surveying, Fiscal, legal and multipurpose cadastre, Graphical and digital cadastre, Nepal cadastral components and records.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Cadastral Surveying Techniques

### Key points
- **Existing maps/images:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Chain/tape, compass, plane table:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Total station and GNSS:** A total station combines electronic angle measurement, electronic distance measurement and onboard computation. It can observe points, calculate coordinates and store field data, making it useful for topographic, cadastral and engineering surveys.
- **Aerial, orthophoto, satellite/UAV and hybrid techniques:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].

### Quick revision
- Unit 2 focuses on: Existing maps/images, Chain/tape, compass, plane table, Total station and GNSS, Aerial, orthophoto, satellite/UAV and hybrid techniques.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Cadastral Maps

### Key points
- **Projection and sheet numbering:** A map projection transforms positions on the curved Earth to a plane. Because a curved surface cannot be flattened without distortion, projections are selected according to the purpose and region of mapping, considering distortion of distance, area, shape or direction.
- **Geodetic control:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Map types and scales:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Plot numbering, plotting tolerance and specifications:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.

### Quick revision
- Unit 3 focuses on: Projection and sheet numbering, Geodetic control, Map types and scales, Plot numbering, plotting tolerance and specifications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Graphical Cadastre

### Key points
- **Graphical parcel representation:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Boundary/parcel plotting:** A parcel is a defined unit of land that can be uniquely identified in a cadastral system. Parcel boundaries should be surveyed and recorded consistently so that the parcel can be linked to its map, register and relevant legal records.
- **Maintenance and limitations:** A limit describes the value that a function approaches as the independent variable approaches a particular value. Limits are the foundation of continuity and differentiation and are evaluated by direct substitution, factorization or other appropriate algebraic methods.

### Quick revision
- Unit 4 focuses on: Graphical parcel representation, Boundary/parcel plotting, Maintenance and limitations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Digital Cadastre

### Key points
- **Data acquisition and boundary survey:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Field sketch and data download:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Digital mapping and database:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Field book and reporting:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.

### Quick revision
- Unit 5 focuses on: Data acquisition and boundary survey, Field sketch and data download, Digital mapping and database, Field book and reporting.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Registration Procedure in Nepal

### Key points
- **Notification and control densification:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Adjudication and field book:** Cadastral adjudication is the process of determining and confirming the rights and interests associated with land parcels. It involves examining evidence, identifying claimants and recording the accepted result in the cadastral and registration system.
- **Land classification and area:** The periodic table arranges elements according to atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy and electronegativity help predict bonding and chemical behaviour.
- **Ownership registration and documents:** Land registration formally records recognized rights in land and links those rights to identifiable parcels. Accurate survey records, supporting documents and consistent parcel identification are important for maintaining reliable registration records.
- **Handover and records:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.

### Quick revision
- Unit 6 focuses on: Notification and control densification, Adjudication and field book, Land classification and area, Ownership registration and documents.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Updating and Archiving Cadastral Documents

### Key points
- **Updating parcel/ownership information:** A parcel is a defined unit of land that can be uniquely identified in a cadastral system. Parcel boundaries should be surveyed and recorded consistently so that the parcel can be linked to its map, register and relevant legal records.
- **Archiving maps and records:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Quality control and retrieval:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.

### Quick revision
- Unit 7 focuses on: Updating parcel/ownership information, Archiving maps and records, Quality control and retrieval.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Cadastral Organizations and Roles in Nepal

### Key points
- **Survey/cadastral institutions:** A cadastre is a parcel-based system that records information about land units, commonly including location, extent, ownership or rights and related records. Cadastral surveying establishes or updates parcel boundaries and produces maps and records used in land administration.
- **Roles in mapping and registration:** Land registration formally records recognized rights in land and links those rights to identifiable parcels. Accurate survey records, supporting documents and consistent parcel identification are important for maintaining reliable registration records.
- **Coordination and service delivery:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.

### Quick revision
- Unit 8 focuses on: Survey/cadastral institutions, Roles in mapping and registration, Coordination and service delivery.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Modern Cadastre

### Key points
- **3D and current legal aspects:** Electric current is the rate of flow of charge, I = Q/t. Ohm’s law for an ohmic conductor is V = IR. Capacitors store electric charge and energy in an electric field; their capacitance relates charge to potential difference by C = Q/V.
- **International examples:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **FIG Vision concepts:** Computer-aided drafting uses commands and digital geometry to create precise drawings. Coordinates, layers, object properties, editing commands, text, dimensions and plotting settings are combined to prepare survey and engineering drawings.
- **Future-oriented cadastral systems:** A cadastre is a parcel-based system that records information about land units, commonly including location, extent, ownership or rights and related records. Cadastral surveying establishes or updates parcel boundaries and produces maps and records used in land administration.

### Quick revision
- Unit 9 focuses on: 3D and current legal aspects, International examples, FIG Vision concepts, Future-oriented cadastral systems.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
