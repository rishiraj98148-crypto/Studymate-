# Geodesy and Astronomy

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Figure of the Earth

### Key points
- **Geoid and reference ellipsoid:** Geoid and reference ellipsoid is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Earth dimensions and shape:** Earth dimensions and shape is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Ellipsoidal parameters:** Ellipsoidal parameters is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Geoid and reference ellipsoid, Earth dimensions and shape, Ellipsoidal parameters.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Coordinate Systems

### Key points
- **Geographic coordinates:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Geocentric and projected coordinates:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Datums and coordinate transformations:** A geodetic datum provides the reference framework used to define positions on the Earth. Datum transformation is required when coordinates from one reference system must be expressed in another compatible datum.

### Quick revision
- Unit 2 focuses on: Geographic coordinates, Geocentric and projected coordinates, Datums and coordinate transformations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Gravimetry

### Key points
- **Gravity and acceleration due to gravity:** Gravity and acceleration due to gravity is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Gravity observations and anomalies:** Gravity observations and anomalies is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Geodetic applications:** Geodetic applications is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Gravity and acceleration due to gravity, Gravity observations and anomalies, Geodetic applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Global Positioning System

### Key points
- **GPS segments and principles:** GNSS determines position from signals received from navigation satellites. A receiver estimates its position from measured signal travel information; differential and RTK techniques use reference information to improve positioning accuracy.
- **Pseudorange and carrier phase:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Positioning methods and field procedure:** Positioning methods and field procedure is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: GPS segments and principles, Pseudorange and carrier phase, Positioning methods and field procedure.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Introduction to Astronomy

### Key points
- **Solar system and celestial bodies:** Solar system and celestial bodies is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Astronomical coordinate concepts:** Astronomical coordinate concepts is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Solar system and celestial bodies, Astronomical coordinate concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Celestial Sphere

### Key points
- **Celestial sphere and reference circles:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Zenith/nadir, horizon and meridian:** Zenith/nadir, horizon and meridian is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Ecliptic and equinoxes:** Ecliptic and equinoxes is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: Celestial sphere and reference circles, Zenith/nadir, horizon and meridian, Ecliptic and equinoxes.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Time

### Key points
- **Solar and sidereal time:** Solar and sidereal time is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Time systems and conversion concepts:** Time systems and conversion concepts is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 7 focuses on: Solar and sidereal time, Time systems and conversion concepts.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Astronomical Observations

### Key points
- **Altitude, azimuth, declination and hour angle:** Altitude, azimuth, declination and hour angle is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Astronomical triangle:** Astronomical triangle is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Observation procedures and reductions:** Observation procedures and reductions is studied in this unit as part of Geodesy and Astronomy. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 8 focuses on: Altitude, azimuth, declination and hour angle, Astronomical triangle, Observation procedures and reductions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
