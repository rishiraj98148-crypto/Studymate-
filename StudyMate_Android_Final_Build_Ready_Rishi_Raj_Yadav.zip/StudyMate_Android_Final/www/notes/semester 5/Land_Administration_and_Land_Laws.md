# Land Administration and Land Laws

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction

### Key points
- **Land administration concept and functions:** Land administration concept and functions is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Land information and institutional framework:** Land information and institutional framework is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Land administration concept and functions, Land information and institutional framework.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Basics of Land Tenure and Rights

### Key points
- **Tenure types:** Tenure types is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Ownership and use rights:** Ownership and use rights is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Rights, restrictions and responsibilities:** Rights, restrictions and responsibilities is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Tenure types, Ownership and use rights, Rights, restrictions and responsibilities.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Land Registration System

### Key points
- **Registration purpose and process:** Land registration formally records recognized rights in land and links those rights to identifiable parcels. Accurate survey records, supporting documents and consistent parcel identification are important for maintaining reliable registration records.
- **Title/parcel records:** A parcel is a defined unit of land that can be uniquely identified in a cadastral system. Parcel boundaries should be surveyed and recorded consistently so that the parcel can be linked to its map, register and relevant legal records.
- **Transaction and updating:** Transaction and updating is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Registration purpose and process, Title/parcel records, Transaction and updating.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Land Valuation Basics

### Key points
- **Valuation purpose and principles:** Valuation purpose and principles is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Factors affecting land value:** Factors affecting land value is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Valuation purpose and principles, Factors affecting land value.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Land Conflicts and Their Resolutions

### Key points
- **Common land conflicts:** Common land conflicts is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Mediation, administrative and legal approaches:** Mediation, administrative and legal approaches is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Common land conflicts, Mediation, administrative and legal approaches.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Basics of Land Management

### Key points
- **Land-use planning:** Land-use planning is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Land information and development control:** Land information and development control is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: Land-use planning, Land information and development control.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Land Reform

### Key points
- **Concept and objectives:** Concept and objectives is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Land reform approaches and Nepal context:** Land reform approaches and Nepal context is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 7 focuses on: Concept and objectives, Land reform approaches and Nepal context.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Land Valuation

### Key points
- **Valuation methods and market factors:** Valuation methods and market factors is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Assessment and documentation:** Assessment and documentation is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 8 focuses on: Valuation methods and market factors, Assessment and documentation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: LIS and Modernizing Land Administration Services

### Key points
- **Land Information System:** Land Information System is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Digital services and data integration:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.
- **Modern land administration:** Modern land administration is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 9 focuses on: Land Information System, Digital services and data integration, Modern land administration.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 10: Land Laws in Nepal

### Key points
- **Key land-related legal concepts:** Key land-related legal concepts is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Land registration, ownership and transactions:** Land registration formally records recognized rights in land and links those rights to identifiable parcels. Accurate survey records, supporting documents and consistent parcel identification are important for maintaining reliable registration records.
- **Institutional/legal compliance:** Institutional/legal compliance is studied in this unit as part of Land Administration and Land Laws. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 10 focuses on: Key land-related legal concepts, Land registration, ownership and transactions, Institutional/legal compliance.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
