# Survey Management

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction and Basic Concept of Project

### Key points
- **Project definition and characteristics:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Survey project lifecycle:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Objectives, scope and deliverables:** Objectives, scope and deliverables is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Project definition and characteristics, Survey project lifecycle, Objectives, scope and deliverables.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Basics of Management

### Key points
- **Planning, organizing, staffing and control:** Planning, organizing, staffing and control is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Time, cost and resource management:** Time, cost and resource management is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 2 focuses on: Planning, organizing, staffing and control, Time, cost and resource management.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Survey Projects Management

### Key points
- **Work breakdown and scheduling:** Work breakdown and scheduling is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Team/resource allocation:** Team/resource allocation is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Quality, cost and progress monitoring:** Quality, cost and progress monitoring is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Work breakdown and scheduling, Team/resource allocation, Quality, cost and progress monitoring.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Proposal and Report Writing Skill

### Key points
- **Project proposal structure:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Technical report structure:** A project is a planned set of activities carried out to achieve defined objectives within available time and resources. A proposal states the problem, objectives, methodology, resources, schedule and expected outputs, while the final report documents the work performed and results obtained.
- **Presentation and documentation:** Presentation and documentation is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Project proposal structure, Technical report structure, Presentation and documentation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Public Relation

### Key points
- **Client communication:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.
- **Stakeholder coordination:** Stakeholder coordination is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Professional communication:** Professional practice requires competence, honesty, responsibility, respect for standards and proper documentation. In surveying, ethical practice also includes careful observation, accurate records, protection of client information and clear communication of limitations.

### Quick revision
- Unit 5 focuses on: Client communication, Stakeholder coordination, Professional communication.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Professionalism

### Key points
- **Professional ethics and responsibility:** Professional practice requires competence, honesty, responsibility, respect for standards and proper documentation. In surveying, ethical practice also includes careful observation, accurate records, protection of client information and clear communication of limitations.
- **Standards, teamwork and conduct:** Standards, teamwork and conduct is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: Professional ethics and responsibility, Standards, teamwork and conduct.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Safety Management

### Key points
- **Field hazards:** A hazard is a potentially damaging event or condition, while disaster occurs when impacts seriously disrupt a community beyond its capacity to cope. Disaster risk is influenced by hazard, exposure, vulnerability and capacity; risk management therefore includes prevention, preparedness, response and recovery.
- **PPE and safe working procedures:** Survey and construction work involves hazards from traffic, terrain, equipment, electricity and weather. Risk is reduced by identifying hazards, using appropriate personal protective equipment, following safe procedures and maintaining communication among field personnel.
- **Risk control:** A hazard is a potentially damaging event or condition, while disaster occurs when impacts seriously disrupt a community beyond its capacity to cope. Disaster risk is influenced by hazard, exposure, vulnerability and capacity; risk management therefore includes prevention, preparedness, response and recovery.

### Quick revision
- Unit 7 focuses on: Field hazards, PPE and safe working procedures, Risk control.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Basics of First Aid

### Key points
- **Basic first-aid principles:** Basic first-aid principles is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Common field injuries:** Common field injuries is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Emergency response and referral:** Emergency response and referral is studied in this unit as part of Survey Management. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 8 focuses on: Basic first-aid principles, Common field injuries, Emergency response and referral.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
