# Engineering Survey

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction to Engineering Survey

### Key points
- **Purpose and types of engineering surveys:** Purpose and types of engineering surveys is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Reconnaissance and control:** Reconnaissance and control is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Construction survey workflow:** Construction survey workflow is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Purpose and types of engineering surveys, Reconnaissance and control, Construction survey workflow.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Route Survey

### Key points
- **Route reconnaissance and alignment:** Route reconnaissance and alignment is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Longitudinal/cross profiles:** Longitudinal/cross profiles is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Chainage and route setting out:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.

### Quick revision
- Unit 2 focuses on: Route reconnaissance and alignment, Longitudinal/cross profiles, Chainage and route setting out.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Curve

### Key points
- **Horizontal circular curves:** Horizontal circular curves is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Elements and setting-out methods:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Vertical curves basics:** Vertical curves basics is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Horizontal circular curves, Elements and setting-out methods, Vertical curves basics.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Area and Volume

### Key points
- **Area from coordinates and ordinates:** Area from coordinates and ordinates is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Volume by sections and contour methods:** A contour is a line joining points of equal elevation. Contour interval is the vertical difference between successive contours. Contours help represent relief and are used to determine slope, drainage patterns, profiles and approximate earthwork requirements.
- **Earthwork computation:** Earthwork computation is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Area from coordinates and ordinates, Volume by sections and contour methods, Earthwork computation.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Site Survey

### Key points
- **Site selection and topographic detail:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].
- **Building/construction setting out:** Set theory studies collections of well-defined objects. Union combines elements from two sets, intersection contains common elements, and complement contains elements outside a set within the universal set. De Morgan’s laws relate complements of unions and intersections.
- **Cut/fill and site control:** Cut/fill and site control is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Site selection and topographic detail, Building/construction setting out, Cut/fill and site control.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Hydrographic Survey

### Key points
- **Water-body survey purpose:** Water-body survey purpose is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Sounding and depth measurement:** Sounding and depth measurement is studied in this unit as part of Engineering Survey. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Hydrographic plotting and applications:** Acids increase hydrogen-ion concentration in aqueous solution, while bases reduce it or provide hydroxide ions depending on the theory used. pH is a measure related to hydrogen-ion concentration; for dilute aqueous solutions pH = −log[H⁺].

### Quick revision
- Unit 6 focuses on: Water-body survey purpose, Sounding and depth measurement, Hydrographic plotting and applications.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
