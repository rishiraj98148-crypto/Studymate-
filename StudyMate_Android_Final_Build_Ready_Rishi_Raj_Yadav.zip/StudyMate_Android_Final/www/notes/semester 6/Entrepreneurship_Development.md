# Entrepreneurship Development

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction to Business & Entrepreneurship

### Key points
- **Business and entrepreneurship concepts:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Entrepreneurial role and importance:** Entrepreneurship involves identifying an opportunity, organizing resources and accepting the responsibilities associated with creating value through a venture. A basic business plan normally describes the product or service, market, operations, resources, costs and expected revenue.
- **Types of business:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 1 focuses on: Business and entrepreneurship concepts, Entrepreneurial role and importance, Types of business.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Exploring and Developing Entrepreneurial Competencies

### Key points
- **Creativity and innovation:** Creativity and innovation is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Risk-taking and decision making:** A hazard is a potentially damaging event or condition, while disaster occurs when impacts seriously disrupt a community beyond its capacity to cope. Disaster risk is influenced by hazard, exposure, vulnerability and capacity; risk management therefore includes prevention, preparedness, response and recovery.
- **Communication, leadership and persistence:** Effective technical communication presents information clearly, accurately and in an organized form. A good report or letter uses an appropriate structure, precise language and enough supporting detail for the intended reader.

### Quick revision
- Unit 2 focuses on: Creativity and innovation, Risk-taking and decision making, Communication, leadership and persistence.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Business Identification and Selection

### Key points
- **Identifying opportunities:** Identifying opportunities is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Market/customer needs:** Market/customer needs is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Selecting feasible business ideas:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.

### Quick revision
- Unit 3 focuses on: Identifying opportunities, Market/customer needs, Selecting feasible business ideas.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Business Plan Formulation

### Key points
- **Business model and objectives:** Trigonometric relations connect the angles and sides of triangles. Important identities include sin²θ + cos²θ = 1 and tanθ = sinθ/cosθ. In surveying, trigonometry is used for bearing, height, distance, slope and coordinate calculations.
- **Market/technical/financial planning:** Market/technical/financial planning is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Implementation and risk considerations:** A hazard is a potentially damaging event or condition, while disaster occurs when impacts seriously disrupt a community beyond its capacity to cope. Disaster risk is influenced by hazard, exposure, vulnerability and capacity; risk management therefore includes prevention, preparedness, response and recovery.

### Quick revision
- Unit 4 focuses on: Business model and objectives, Market/technical/financial planning, Implementation and risk considerations.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Small Business Management

### Key points
- **Operations and staffing:** Operations and staffing is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Finance and marketing basics:** Finance and marketing basics is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Record keeping and growth:** Record keeping and growth is studied in this unit as part of Entrepreneurship Development. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Operations and staffing, Finance and marketing basics, Record keeping and growth.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
