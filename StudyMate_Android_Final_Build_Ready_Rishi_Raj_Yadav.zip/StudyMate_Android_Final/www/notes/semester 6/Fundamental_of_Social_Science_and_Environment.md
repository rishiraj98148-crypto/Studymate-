# Fundamental of Social Science and Environment

## Direct Study Notes

These study notes follow the unit/topic structure of the supplied CTEVT syllabus. Explanations are written as study aids and do not replace the official syllabus or textbook.

## Unit 1: Introduction to Society

### Key points
- **Society, community and social structure:** Society, community and social structure is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Culture and social institutions:** Culture and social institutions is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 1 focuses on: Society, community and social structure, Culture and social institutions.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 2: Process of Social Change and Integration

### Key points
- **Social change factors:** Social change factors is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Integration, inclusion and cohesion:** Integration is the inverse process of differentiation and is used to find accumulated quantities such as area and volume. For example, ∫x^n dx = x^(n+1)/(n+1) + C for n ≠ −1. Definite integration is evaluated between specified limits.

### Quick revision
- Unit 2 focuses on: Social change factors, Integration, inclusion and cohesion.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 3: Challenges to Nepali Society

### Key points
- **Social inequality and exclusion:** Social inequality and exclusion is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Migration, population and development issues:** Migration, population and development issues is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 3 focuses on: Social inequality and exclusion, Migration, population and development issues.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 4: Basics of Governance System in Nepal

### Key points
- **Governance concepts:** Governance concepts is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Federal, provincial and local levels:** Federal, provincial and local levels is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Public participation and accountability:** Public participation and accountability is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 4 focuses on: Governance concepts, Federal, provincial and local levels, Public participation and accountability.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 5: Sustainable Development and Community

### Key points
- **Development concepts and community participation:** Development concepts and community participation is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Local resource and development planning:** Local resource and development planning is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 5 focuses on: Development concepts and community participation, Local resource and development planning.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 6: Resource Mobilization for Community Development

### Key points
- **Local resources:** Local resources is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Participation and mobilization methods:** Participation and mobilization methods is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 6 focuses on: Local resources, Participation and mobilization methods.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 7: Environment Protection

### Key points
- **Environmental components:** The environment includes living and non-living components and the interactions among them. Environmental protection aims to reduce harmful impacts, conserve resources and maintain ecological functions for present and future needs.
- **Pollution and conservation:** Pollution and conservation is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Sustainable practices:** Sustainable practices is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 7 focuses on: Environmental components, Pollution and conservation, Sustainable practices.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 8: Disaster Risk Management

### Key points
- **Hazard, vulnerability and risk:** A hazard is a potentially damaging event or condition, while disaster occurs when impacts seriously disrupt a community beyond its capacity to cope. Disaster risk is influenced by hazard, exposure, vulnerability and capacity; risk management therefore includes prevention, preparedness, response and recovery.
- **Preparedness, mitigation, response and recovery:** Preparedness, mitigation, response and recovery is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 8 focuses on: Hazard, vulnerability and risk, Preparedness, mitigation, response and recovery.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Unit 9: Climate Change

### Key points
- **Causes and impacts:** Causes and impacts is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Adaptation and mitigation:** Adaptation and mitigation is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.
- **Nepal context:** Nepal context is studied in this unit as part of Fundamental of Social Science and Environment. The topic should be understood in terms of its meaning, main concepts, important steps or characteristics, and its use in the context described by the CTEVT syllabus. For examination preparation, learn the key definition, explain the main points in order, and include a suitable example or diagram when the topic requires one.

### Quick revision
- Unit 9 focuses on: Causes and impacts, Adaptation and mitigation, Nepal context.
- **Exam writing:** Start with the definition or principle, explain the required points in logical order, and add the relevant formula, field step, example or diagram from the syllabus.

## Exam Focus
- Definitions and terminology from the syllabus
- Short notes, classifications and principles
- Procedures, field steps and numerical/formula-based problems where specified
- Diagrams, examples and engineering/survey applications
