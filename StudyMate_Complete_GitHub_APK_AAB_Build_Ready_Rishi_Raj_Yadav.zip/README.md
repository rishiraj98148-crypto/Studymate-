# StudyMate — Android Build-Ready Project

**Diploma Engineering Study Hub**

**Developed by Rishi Raj Yadav**  
Package ID: `com.rishirajyadav.studymate`

## Project contents
- `www/` — StudyMate web app, notes and figures
- `assets/` — project assets
- `capacitor.config.ts` — Capacitor configuration
- `package.json` — Capacitor dependencies
- `.github/workflows/build-apk.yml` — GitHub Actions APK/AAB build

## GitHub Actions build
The workflow automatically:
1. Checks out the repository
2. Installs Node.js 22 and Java 21
3. Installs npm dependencies
4. Creates the Android platform with Capacitor
5. Syncs the web app
6. Builds a debug APK and release AAB
7. Uploads both files as workflow artifacts

No `android/` folder is required in the ZIP because the workflow creates it with `npx cap add android`.

## Important GitHub upload instruction
After extracting this ZIP, upload the **contents** of the extracted project folder to the **repository root**. Do not upload the ZIP itself as the only repository file.

The repository root must directly show:
- `.github/`
- `www/`
- `assets/`
- `capacitor.config.ts`
- `package.json`
- `README.md`

Keep the `.github/workflows/build-apk.yml` path exactly as shown.

## Run build
Open GitHub → Actions → **Build StudyMate APK and AAB** → **Run workflow**.
After the workflow completes, open the run and download:
- `StudyMate-debug-apk`
- `StudyMate-release-aab-unsigned`
